import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./src/**/*.{js,ts,jsx,tsx,mdx}"],
  theme: {
    extend: {
      colors: {
        panel: {
          bg: "#0b1220",
          surface: "#111a2c",
          border: "#22304a",
        },
        brand: {
          50: "#eef4ff",
          100: "#dce8ff",
          300: "#93b4ff",
          500: "#3d63e0",
          600: "#2f4fc0",
          700: "#26409c",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
      },
    },
  },
  plugins: [],
};

export default config;
