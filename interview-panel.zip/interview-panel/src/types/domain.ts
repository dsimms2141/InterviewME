// Shared domain types used across the LLM services, orchestrator, avatar
// layer, and UI. Kept independent of Prisma's generated types so the LLM
// prompts/schemas can evolve without touching the DB layer directly.

export type InterviewMode = "PRACTICE" | "REALISTIC" | "PRESSURE";

export interface CompetencyProfile {
  industry: string;
  seniority: string;
  responsibilities: string[];
  requiredSkills: string[];
  leadershipExpectations: string[];
  technicalCompetencies: string[];
  behavioralCompetencies: string[];
  customerResponsibilities: string[];
  problemSolvingExpectations: string[];
  communicationRequirements: string[];
  managementExpectations: string[];
  relevantTerminology: string[];
}

export interface GeneratedInterviewer {
  firstName: string;
  lastName: string;
  title: string;
  department: string;
  primaryCompetency: string;
  interviewStyle: string;
  personality: {
    traits: string[]; // e.g. ["warm", "detail-oriented", "direct"]
    tone: string; // short description used to steer LLM-generated dialogue
  };
  appearanceSeed: {
    genderPresentation: "masculine" | "feminine" | "androgynous";
    agePresentation: "younger" | "mid-career" | "senior";
    skinTone: string; // descriptive, used only to request/select a diverse
                       // avatar asset — never tied to scoring
    hairstyle: string;
    attire: string;
  };
  voiceProfile: {
    gender: "male" | "female" | "neutral";
    accent: string;
    pace: "slower" | "moderate" | "brisk";
  };
  seatOrder: 1 | 2 | 3;
}

export interface GeneratedPanel {
  interviewers: GeneratedInterviewer[];
}

export type QuestionCategory =
  | "BEHAVIORAL_EXPERIENCE"
  | "SCENARIO_SITUATIONAL"
  | "PROBLEM_RESOLUTION"
  | "COMMUNICATION_LEADERSHIP"
  | "ROLE_SPECIFIC_CHALLENGE"
  | "FOLLOW_UP";

export interface GeneratedQuestion {
  order: number;
  category: QuestionCategory;
  text: string;
  testingFor: string;
  askedBySeatOrder: 1 | 2 | 3;
}

export interface FollowUpDecision {
  shouldFollowUp: boolean;
  followUpQuestion?: string;
  reason?: string;
}

export interface ObservableSignals {
  speakingPaceWpm: number;
  fillerWordCount: number;
  longPauseCount: number;
  durationSeconds: number;
  starDetected: boolean;
}

export interface QuestionEvaluation {
  questionText: string;
  transcript: string;
  whatWorked: string;
  whatCouldBeStronger: string;
  whatQuestionTested: string;
  missingInformation: string;
  star: {
    situation: string;
    task: string;
    action: string;
    result: string;
  };
  betterAnswerStructure: string;
  coachingNotes: string;
  practiceRecommendation: string;
}

export type ReadinessLevel = "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE";

export interface ReadinessReport {
  overallSummary: string;
  levels: {
    answerStructure: ReadinessLevel;
    relevance: ReadinessLevel;
    specificity: ReadinessLevel;
    problemSolving: ReadinessLevel;
    communication: ReadinessLevel;
    starUsage: ReadinessLevel;
    conciseness: ReadinessLevel;
    roleKnowledge: ReadinessLevel;
  };
  strengths: string[];
  growthAreas: string[];
}

export interface PlaybookContent {
  position: string;
  jobCompetencies: string[];
  panelQuestions: { question: string; answerSummary: string }[];
  followUpQuestions: { question: string; answerSummary: string }[];
  feedback: string;
  improvedAnswerStructures: string[];
  candidateExamplesUsed: string[];
  starStories: { title: string; situation: string; task: string; action: string; result: string }[];
  areasToPractice: string[];
  roleTalkingPoints: string[];
  commonQuestionsToPrepare: string[];
  finalChecklist: string[];
}
