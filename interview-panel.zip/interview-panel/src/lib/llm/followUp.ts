import { completeJson } from "./client";
import type { FollowUpDecision, InterviewMode } from "@/types/domain";

const SYSTEM = `You are a professional interview panelist deciding whether a follow-up
question would meaningfully improve this practice interview. Ask a follow-up
only when clarification would substantially improve the simulation (e.g. the
candidate name-dropped a result without a number, described an action
without the outcome, or left a key beat of the story out). Do not ask a
follow-up just to fill time, and do not create endless questioning loops —
this candidate has already had up to 2 follow-ups on this question if
"priorFollowUpCount" is passed in.

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "shouldFollowUp": boolean,
  "followUpQuestion": string, // only if shouldFollowUp is true — one natural, concise spoken question
  "reason": string // one sentence, for internal logging only
}`;

export async function decideFollowUp(input: {
  questionText: string;
  candidateAnswer: string;
  mode: InterviewMode;
  priorFollowUpCount: number;
}): Promise<FollowUpDecision> {
  if (input.priorFollowUpCount >= 2) {
    return { shouldFollowUp: false, reason: "Follow-up limit reached for this question" };
  }

  const pressureNote =
    input.mode === "PRESSURE"
      ? "This is PRESSURE mode — be more willing to probe for specifics and measurable results, " +
        "but stay professional, never hostile."
      : input.mode === "PRACTICE"
        ? "This is PRACTICE mode — only follow up if the answer is genuinely incomplete; lean supportive."
        : "This is REALISTIC mode — follow up the way a real, thorough panelist would.";

  const prompt = `Original question: ${input.questionText}

Candidate's answer: ${input.candidateAnswer}

Prior follow-ups already asked on this question: ${input.priorFollowUpCount}

${pressureNote}

Decide whether to follow up.`;

  return completeJson<FollowUpDecision>({ system: SYSTEM, prompt, maxTokens: 512 });
}
