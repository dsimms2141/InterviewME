import { completeJson } from "./client";
import type { CompetencyProfile, PlaybookContent, QuestionEvaluation, ReadinessReport } from "@/types/domain";

const SYSTEM = `You assemble a personalized INTERVIEW PLAYBOOK from a completed mock
interview so the candidate can prepare for their real interview. Reuse the
candidate's own real examples wherever they gave one; only add a bracketed
placeholder (e.g. "[your specific metric]") where their answer lacked
something a strong answer would include — never fabricate an experience or
outcome on their behalf.

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "position": string,
  "jobCompetencies": string[],
  "panelQuestions": [{ "question": string, "answerSummary": string }],
  "followUpQuestions": [{ "question": string, "answerSummary": string }],
  "feedback": string,
  "improvedAnswerStructures": string[],
  "candidateExamplesUsed": string[],
  "starStories": [{ "title": string, "situation": string, "task": string, "action": string, "result": string }],
  "areasToPractice": string[],
  "roleTalkingPoints": string[],
  "commonQuestionsToPrepare": string[],
  "finalChecklist": string[]
}`;

export async function generatePlaybook(input: {
  jobTitle: string;
  competencyProfile: CompetencyProfile;
  evaluations: QuestionEvaluation[];
  followUpEvaluations: QuestionEvaluation[];
  readinessReport: ReadinessReport;
}): Promise<PlaybookContent> {
  const prompt = `Job title: ${input.jobTitle}
Key competencies: ${[
    ...input.competencyProfile.requiredSkills,
    ...input.competencyProfile.behavioralCompetencies,
  ].join("; ")}

Primary question evaluations:
${input.evaluations
  .map((e) => `Q: ${e.questionText}\nA summary: ${e.transcript.slice(0, 400)}\nCoaching: ${e.coachingNotes}`)
  .join("\n\n")}

Follow-up evaluations:
${
  input.followUpEvaluations
    .map((e) => `Q: ${e.questionText}\nA summary: ${e.transcript.slice(0, 300)}`)
    .join("\n\n") || "(none asked)"
}

Overall readiness summary: ${input.readinessReport.overallSummary}
Growth areas: ${input.readinessReport.growthAreas.join("; ")}

Assemble the full playbook now.`;

  return completeJson<PlaybookContent>({ system: SYSTEM, prompt, maxTokens: 4096 });
}
