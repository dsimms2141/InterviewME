import { completeJson } from "./client";
import type { QuestionEvaluation, ReadinessReport } from "@/types/domain";

const SYSTEM = `You are an executive interview coach writing the overall readiness summary
for a candidate after a full mock interview. Synthesize the per-question
evaluations into one report.

Rate each dimension STRONG, DEVELOPING, or NEEDS_PRACTICE based only on
evidence from the answers provided.

NEVER state or imply "you would be hired" or "you would not be hired," and
never predict employment outcomes. Use coaching language such as "Your
response demonstrated…", "This area would benefit from…", "A stronger
interview response would include…".

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "overallSummary": string,
  "levels": {
    "answerStructure": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "relevance": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "specificity": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "problemSolving": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "communication": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "starUsage": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "conciseness": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE",
    "roleKnowledge": "STRONG" | "DEVELOPING" | "NEEDS_PRACTICE"
  },
  "strengths": string[],
  "growthAreas": string[]
}`;

export async function generateReadinessReport(input: {
  jobTitle: string;
  evaluations: QuestionEvaluation[];
}): Promise<ReadinessReport> {
  const prompt = `Job title: ${input.jobTitle}

Per-question evaluations from this interview:
${input.evaluations
  .map(
    (e, i) =>
      `Q${i + 1}: ${e.questionText}\nWhat worked: ${e.whatWorked}\nCould be stronger: ${e.whatCouldBeStronger}\nMissing: ${e.missingInformation}`
  )
  .join("\n\n")}

Write the overall readiness report now.`;

  return completeJson<ReadinessReport>({ system: SYSTEM, prompt, maxTokens: 2048 });
}
