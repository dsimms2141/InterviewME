import { completeJson } from "./client";
import type { CompetencyProfile, GeneratedPanel } from "@/types/domain";

const SYSTEM = `You are designing a THREE-PERSON interview panel for a job-interview
practice platform. The panel composition must make organizational sense for
the role (see section 6 of the product spec: e.g. an Operations Manager
candidate meets a Regional Operations Director, a Senior HR Business
Partner, and a District/Department Manager).

Requirements:
- Exactly 3 interviewers, each with a distinct primary competency so their
  questions won't overlap.
- Vary names, gender presentation, age presentation, skin tone, hairstyle,
  and attire across calls — do not default to the same demographic pattern
  every time. Diversity in appearance must NEVER be tied to competence,
  seniority, personality, or how the candidate will be scored — appearance
  fields are purely for avatar rendering.
- Each interviewer needs a believable first/last name, a professional title
  and department that fits the job's industry and seniority, a one-line
  interview style, and 2-4 personality traits that will steer their
  question tone (e.g. warm vs. direct) without becoming a caricature.
- seatOrder must be 1, 2, and 3 exactly once each (left-to-right seating in
  the interview room).

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "interviewers": [
    {
      "firstName": string,
      "lastName": string,
      "title": string,
      "department": string,
      "primaryCompetency": string,
      "interviewStyle": string,
      "personality": { "traits": string[], "tone": string },
      "appearanceSeed": {
        "genderPresentation": "masculine" | "feminine" | "androgynous",
        "agePresentation": "younger" | "mid-career" | "senior",
        "skinTone": string,
        "hairstyle": string,
        "attire": string
      },
      "voiceProfile": { "gender": "male" | "female" | "neutral", "accent": string, "pace": "slower" | "moderate" | "brisk" },
      "seatOrder": 1 | 2 | 3
    }
  ]
}`;

export async function generatePanel(input: {
  jobTitle: string;
  competencyProfile: CompetencyProfile;
}): Promise<GeneratedPanel> {
  const prompt = `Job title: ${input.jobTitle}
Industry: ${input.competencyProfile.industry}
Seniority: ${input.competencyProfile.seniority}
Key responsibilities: ${input.competencyProfile.responsibilities.join("; ")}
Leadership expectations: ${input.competencyProfile.leadershipExpectations.join("; ") || "none"}
Management expectations: ${input.competencyProfile.managementExpectations.join("; ") || "none"}

Generate the 3-person panel now. Vary the panel's demographic presentation
from any "typical" default — do not always produce the same gender/age
pattern for a given seat.`;

  const panel = await completeJson<GeneratedPanel>({ system: SYSTEM, prompt, maxTokens: 2048 });

  const seats = panel.interviewers.map((i) => i.seatOrder).sort();
  if (panel.interviewers.length !== 3 || JSON.stringify(seats) !== JSON.stringify([1, 2, 3])) {
    throw new Error("Panel generation returned an invalid panel (expected exactly seats 1, 2, 3)");
  }

  return panel;
}
