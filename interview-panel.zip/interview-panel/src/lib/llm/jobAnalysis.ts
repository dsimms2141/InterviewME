import { completeJson } from "./client";
import type { CompetencyProfile } from "@/types/domain";

const SYSTEM = `You are an expert talent-acquisition analyst. Given a job title and,
when available, a job description, extract a structured INTERVIEW COMPETENCY
PROFILE that will drive interview-panel generation and question generation
for an interview-practice product. Be specific to the role; avoid generic
boilerplate when the job description gives you real detail. Respond with
ONLY a JSON object, no prose, matching exactly this TypeScript shape:

{
  "industry": string,
  "seniority": string, // e.g. "Individual contributor", "First-line manager", "Senior leader"
  "responsibilities": string[],
  "requiredSkills": string[],
  "leadershipExpectations": string[], // [] if not a leadership role
  "technicalCompetencies": string[],
  "behavioralCompetencies": string[],
  "customerResponsibilities": string[], // [] if not customer-facing
  "problemSolvingExpectations": string[],
  "communicationRequirements": string[],
  "managementExpectations": string[], // [] if not a management role
  "relevantTerminology": string[] // industry/role jargon a strong candidate would use naturally
}`;

export async function analyzeJob(input: {
  title: string;
  description?: string;
}): Promise<CompetencyProfile> {
  const prompt = input.description
    ? `Job title: ${input.title}\n\nJob description:\n${input.description}`
    : `Job title: ${input.title}\n\n(No job description was provided — infer a realistic ` +
      `competency profile for this title using standard industry expectations.)`;

  return completeJson<CompetencyProfile>({ system: SYSTEM, prompt, maxTokens: 2048 });
}
