import Anthropic from "@anthropic-ai/sdk";

// Every LLM call in this app goes through this one wrapper. Swapping vendors
// (or adding a fallback vendor for resilience) means editing this file only —
// no call site elsewhere imports the Anthropic SDK directly.

let client: Anthropic | null = null;

function getClient(): Anthropic {
  if (!client) {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error(
        "ANTHROPIC_API_KEY is not set. Add it to .env (see .env.example) before " +
          "calling any job-analysis, panel-generation, question-generation, or " +
          "coaching endpoint."
      );
    }
    client = new Anthropic({ apiKey });
  }
  return client;
}

const DEFAULT_MODEL = process.env.LLM_MODEL || "claude-sonnet-5";

/**
 * Calls the LLM with a system prompt + user prompt and expects a single
 * JSON object back, matching the shape callers request in their prompt.
 * Centralizing "ask for JSON, strip markdown fences, JSON.parse" here keeps
 * every service function (jobAnalysis, panelGeneration, ...) short.
 */
export async function completeJson<T>(params: {
  system: string;
  prompt: string;
  maxTokens?: number;
}): Promise<T> {
  const anthropic = getClient();
  const message = await anthropic.messages.create({
    model: DEFAULT_MODEL,
    max_tokens: params.maxTokens ?? 4096,
    system: params.system,
    messages: [{ role: "user", content: params.prompt }],
  });

  const textBlock = message.content.find((block) => block.type === "text");
  if (!textBlock || textBlock.type !== "text") {
    throw new Error("LLM response contained no text block");
  }

  const raw = textBlock.text.trim();
  const jsonText = stripCodeFence(raw);

  try {
    return JSON.parse(jsonText) as T;
  } catch (err) {
    throw new Error(
      `Failed to parse LLM JSON response: ${(err as Error).message}\nRaw: ${raw.slice(0, 500)}`
    );
  }
}

function stripCodeFence(text: string): string {
  const fenced = text.match(/```(?:json)?\s*([\s\S]*?)```/i);
  return fenced ? fenced[1]!.trim() : text;
}
