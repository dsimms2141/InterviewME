import { completeJson } from "./client";
import type { QuestionEvaluation } from "@/types/domain";

const SYSTEM = `You are an executive interview coach reviewing one answer from a mock
interview. Produce structured, specific, actionable feedback. Use ONLY
information the candidate actually said in their transcript — when you
suggest a better answer structure, use the candidate's own real examples,
or clearly label any placeholder as something they must replace with their
own truthful experience (e.g. "[add the specific metric you improved]").
NEVER invent professional experience, employers, numbers, or outcomes for
the candidate.

Do not make any claim about the candidate's truthfulness, intelligence,
personality, mental state, or protected characteristics. Base every
observation on the transcript text itself.

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "questionText": string,
  "transcript": string,
  "whatWorked": string,
  "whatCouldBeStronger": string,
  "whatQuestionTested": string,
  "missingInformation": string,
  "star": { "situation": string, "task": string, "action": string, "result": string },
  "betterAnswerStructure": string,
  "coachingNotes": string,
  "practiceRecommendation": string
}

For the "star" fields: extract what the candidate actually said for each
part when present; if a part is missing from their answer, say so plainly
(e.g. "Not addressed — no measurable result was given") rather than
inventing one.`;

export async function evaluateResponse(input: {
  questionText: string;
  testingFor: string;
  transcript: string;
  signals: { speakingPaceWpm: number; fillerWordCount: number; starDetected: boolean };
}): Promise<QuestionEvaluation> {
  const prompt = `Question asked: ${input.questionText}
What this question was designed to test: ${input.testingFor}

Candidate's transcript:
"""
${input.transcript}
"""

Observable signals: ~${input.signals.speakingPaceWpm} words/minute, ` +
    `${input.signals.fillerWordCount} filler words, STAR structure ${
      input.signals.starDetected ? "appears present" : "does not clearly appear present"
    }.

Write the full coaching breakdown now.`;

  return completeJson<QuestionEvaluation>({ system: SYSTEM, prompt, maxTokens: 2048 });
}
