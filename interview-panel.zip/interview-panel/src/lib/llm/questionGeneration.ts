import { completeJson } from "./client";
import type { CompetencyProfile, GeneratedInterviewer, GeneratedQuestion, InterviewMode } from "@/types/domain";

const SYSTEM = `You write interview questions for a job-interview practice platform.
Generate exactly FIVE primary questions customized to the job's title,
seniority, industry, competencies, and responsibilities. Avoid generic
questions whenever the competency profile gives you enough to be specific.

The five questions must cover, in this order:
1. BEHAVIORAL_EXPERIENCE — a past-experience / behavioral question
2. SCENARIO_SITUATIONAL — a hypothetical scenario the candidate could face in this role
3. PROBLEM_RESOLUTION — a problem-solving / conflict-resolution question
4. COMMUNICATION_LEADERSHIP — communication, leadership, or teamwork (adapt to
   seniority: individual-contributor roles get a teamwork/collaboration
   framing rather than a people-management one)
5. ROLE_SPECIFIC_CHALLENGE — a challenge specific to this exact role/industry

For leadership or management roles, prefer topics like employee performance,
coaching, accountability, conflict, staffing, operational decisions, customer
experience, metrics, change management, prioritization, developing
employees, or difficult conversations where they fit naturally into the
five categories above.

Assign each question to a panel seat (1, 2, or 3) whose primaryCompetency
best matches that question's focus.

Also write "testingFor": one sentence naming the underlying competency the
question is designed to surface (used later for coaching, not shown to the
candidate during the live interview).

Respond with ONLY a JSON object matching exactly this TypeScript shape:

{
  "questions": [
    { "order": number, "category": "BEHAVIORAL_EXPERIENCE" | "SCENARIO_SITUATIONAL" | "PROBLEM_RESOLUTION" | "COMMUNICATION_LEADERSHIP" | "ROLE_SPECIFIC_CHALLENGE", "text": string, "testingFor": string, "askedBySeatOrder": 1 | 2 | 3 }
  ]
}`;

export async function generateQuestions(input: {
  jobTitle: string;
  competencyProfile: CompetencyProfile;
  interviewers: GeneratedInterviewer[];
  mode: InterviewMode;
}): Promise<GeneratedQuestion[]> {
  const modeGuidance =
    input.mode === "PRACTICE"
      ? "PRACTICE mode: keep questions supportive and straightforward — this is a low-pressure warm-up."
      : input.mode === "PRESSURE"
        ? "PRESSURE mode: make questions more challenging and precise, with higher expectations for " +
          "specificity — but never abusive, discriminatory, or intentionally humiliating."
        : "REALISTIC mode: write questions the way an actual professional panel would ask them.";

  const prompt = `Job title: ${input.jobTitle}
Industry: ${input.competencyProfile.industry}
Seniority: ${input.competencyProfile.seniority}
Responsibilities: ${input.competencyProfile.responsibilities.join("; ")}
Required skills: ${input.competencyProfile.requiredSkills.join("; ")}
Behavioral competencies: ${input.competencyProfile.behavioralCompetencies.join("; ")}
Problem-solving expectations: ${input.competencyProfile.problemSolvingExpectations.join("; ")}
Communication requirements: ${input.competencyProfile.communicationRequirements.join("; ")}
Leadership expectations: ${input.competencyProfile.leadershipExpectations.join("; ") || "none"}

Panel seats:
${input.interviewers.map((i) => `Seat ${i.seatOrder}: ${i.firstName} ${i.lastName}, ${i.title} — primary competency: ${i.primaryCompetency}`).join("\n")}

${modeGuidance}

Generate the five primary questions now.`;

  const result = await completeJson<{ questions: GeneratedQuestion[] }>({
    system: SYSTEM,
    prompt,
    maxTokens: 2048,
  });

  if (result.questions.length !== 5) {
    throw new Error(`Question generation returned ${result.questions.length} questions, expected 5`);
  }

  return result.questions;
}
