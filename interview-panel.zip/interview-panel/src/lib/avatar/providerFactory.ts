import type { AvatarProvider } from "./types";
import { AvatarProviderError } from "./types";
import { MockAvatarProvider } from "./providers/mockProvider";
import { AnamAvatarProvider } from "./providers/anamProvider";

let cachedProvider: AvatarProvider | null = null;
let cachedFallback: AvatarProvider | null = null;

/**
 * Returns the configured AvatarProvider. AVATAR_PROVIDER selects the
 * implementation; the mock provider is always available as a graceful
 * fallback (section 8: "Build graceful fallback handling if the avatar
 * provider temporarily fails") so a vendor outage degrades the interview
 * to non-animated-but-functional rather than crashing the session.
 */
export function getAvatarProvider(): AvatarProvider {
  if (cachedProvider) return cachedProvider;

  const selected = process.env.AVATAR_PROVIDER || "mock";

  switch (selected) {
    case "anam": {
      const apiKey = process.env.ANAM_API_KEY;
      if (!apiKey) {
        console.warn("AVATAR_PROVIDER=anam but ANAM_API_KEY is unset; falling back to mock provider.");
        cachedProvider = new MockAvatarProvider();
      } else {
        cachedProvider = new AnamAvatarProvider(apiKey);
      }
      break;
    }
    case "mock":
    default:
      cachedProvider = new MockAvatarProvider();
  }

  return cachedProvider;
}

function getFallbackProvider(): AvatarProvider {
  if (!cachedFallback) cachedFallback = new MockAvatarProvider();
  return cachedFallback;
}

/**
 * Wraps a provider call so a recoverable provider failure (network error,
 * 5xx, rate limit) degrades to the mock provider for that one call instead
 * of failing the whole interview turn. Non-recoverable errors (bad request,
 * auth failure) still propagate — those need a human to fix configuration,
 * not a silent downgrade.
 */
export async function withAvatarFallback<T>(
  fn: (provider: AvatarProvider) => Promise<T>
): Promise<T> {
  const primary = getAvatarProvider();
  try {
    return await fn(primary);
  } catch (err) {
    if (err instanceof AvatarProviderError && err.recoverable && primary.name !== "mock") {
      console.error(`Avatar provider "${primary.name}" failed recoverably, falling back to mock:`, err.message);
      return fn(getFallbackProvider());
    }
    throw err;
  }
}
