// Provider-agnostic avatar contract. See docs/ARCHITECTURE.md section 8.
// Every real-time avatar vendor (Anam, HeyGen LiveAvatar, Simli, Tavus, ...)
// is wrapped to implement this interface so the app never imports a vendor
// SDK outside lib/avatar/providers/*.

export type AvatarState = "IDLE" | "LISTENING" | "SPEAKING" | "THINKING" | "TRANSITIONING";

export interface AvatarPersonaRequest {
  interviewerId: string;
  displayName: string;
  appearanceSeed: {
    genderPresentation: "masculine" | "feminine" | "androgynous";
    agePresentation: "younger" | "mid-career" | "senior";
    skinTone: string;
    hairstyle: string;
    attire: string;
  };
  voiceProfile: {
    gender: "male" | "female" | "neutral";
    accent: string;
    pace: "slower" | "moderate" | "brisk";
  };
}

export interface AvatarSessionHandle {
  sessionId: string;
  interviewerId: string;
  /** Vendor-specific client connection info (e.g. LiveKit/WebRTC join token
   *  and room URL) that the browser-side player component needs. Kept as an
   *  opaque record so each provider can return whatever its client SDK
   *  requires without widening this interface. */
  connectionInfo: Record<string, unknown>;
}

export interface SpeakOptions {
  /** Pre-synthesized audio to lip-sync to (audio-passthrough / BYO-TTS mode),
   *  used when the app's own TTS provider (see lib/speech/tts.ts) already
   *  generated the audio. When omitted, providers that support native
   *  text-to-speech may synthesize from `text` directly. */
  audio?: { url: string; mimeType: string } | { base64: string; mimeType: string };
  text: string;
}

/**
 * AvatarProvider is the seam described in section 8 of the product spec:
 *   TEXT -> LLM RESPONSE -> TEXT-TO-SPEECH -> AVATAR SPEECH/LIP SYNC -> STREAM
 * Swapping the real-time avatar vendor means writing one new class here and
 * flipping the AVATAR_PROVIDER env var — nothing else in the app changes.
 */
export interface AvatarProvider {
  readonly name: string;

  createSession(persona: AvatarPersonaRequest): Promise<AvatarSessionHandle>;
  loadAvatar(session: AvatarSessionHandle): Promise<void>;
  speak(session: AvatarSessionHandle, options: SpeakOptions): Promise<void>;
  stopSpeaking(session: AvatarSessionHandle): Promise<void>;
  setListeningState(session: AvatarSessionHandle): Promise<void>;
  setIdleState(session: AvatarSessionHandle): Promise<void>;
  destroySession(session: AvatarSessionHandle): Promise<void>;
}

export class AvatarProviderError extends Error {
  constructor(
    message: string,
    public readonly provider: string,
    public readonly recoverable: boolean
  ) {
    super(message);
    this.name = "AvatarProviderError";
  }
}
