import { AvatarProviderError, type AvatarPersonaRequest, type AvatarProvider, type AvatarSessionHandle, type SpeakOptions } from "../types";

const ANAM_API_BASE = "https://api.anam.ai/v1";

/**
 * Anam.ai, in audio-passthrough mode: Anam renders the lip-synced avatar
 * video over WebRTC from audio this app already generated via its own TTS
 * provider (lib/speech/tts.ts) — Anam does no STT/LLM/TTS of its own here,
 * it is purely the "avatar speech/lip-sync" stage in the pipeline
 * (TEXT -> LLM -> TTS -> AVATAR LIP SYNC -> STREAM, section 8).
 *
 * Chosen as the default production provider because it: publishes clear
 * per-second self-serve pricing, supports BYO-TTS so panelist voices can
 * be generated once by lib/speech/tts.ts and reused across avatar/session
 * boundaries, and integrates over standard WebRTC so the browser-side
 * player needs no vendor-specific video codec handling. See
 * docs/ARCHITECTURE.md section 8 for the comparison against HeyGen
 * LiveAvatar, Simli, and Tavus that led to this choice, and for how to
 * swap it.
 *
 * NOTE: this wraps Anam's session + audio-passthrough REST/WebRTC surface
 * as documented at https://docs.anam.ai — confirm exact endpoint paths and
 * payload shapes against the current API reference before going live; the
 * account's persona/avatar assets also need to be provisioned (or created
 * from `appearanceSeed` via Anam's persona-generation flow) ahead of the
 * first live session.
 */
export class AnamAvatarProvider implements AvatarProvider {
  readonly name = "anam";

  private readonly apiKey: string;

  constructor(apiKey: string) {
    this.apiKey = apiKey;
  }

  async createSession(persona: AvatarPersonaRequest): Promise<AvatarSessionHandle> {
    const res = await this.fetch("/sessions", {
      method: "POST",
      body: JSON.stringify({
        personaId: persona.interviewerId,
        mode: "audio_passthrough",
        displayName: persona.displayName,
      }),
    });

    const data = (await res.json()) as { sessionId: string; livekitUrl: string; livekitToken: string };

    return {
      sessionId: data.sessionId,
      interviewerId: persona.interviewerId,
      connectionInfo: { livekitUrl: data.livekitUrl, livekitToken: data.livekitToken },
    };
  }

  async loadAvatar(session: AvatarSessionHandle): Promise<void> {
    await this.fetch(`/sessions/${session.sessionId}/ready`, { method: "POST" });
  }

  async speak(session: AvatarSessionHandle, options: SpeakOptions): Promise<void> {
    if (!options.audio) {
      throw new AvatarProviderError(
        "AnamAvatarProvider requires pre-synthesized audio (audio-passthrough mode); " +
          "generate it with lib/speech/tts.ts before calling speak().",
        this.name,
        false
      );
    }

    await this.fetch(`/sessions/${session.sessionId}/audio`, {
      method: "POST",
      body: JSON.stringify({ audio: options.audio, text: options.text }),
    });
  }

  async stopSpeaking(session: AvatarSessionHandle): Promise<void> {
    await this.fetch(`/sessions/${session.sessionId}/audio/stop`, { method: "POST" });
  }

  async setListeningState(session: AvatarSessionHandle): Promise<void> {
    await this.fetch(`/sessions/${session.sessionId}/state`, {
      method: "POST",
      body: JSON.stringify({ state: "listening" }),
    });
  }

  async setIdleState(session: AvatarSessionHandle): Promise<void> {
    await this.fetch(`/sessions/${session.sessionId}/state`, {
      method: "POST",
      body: JSON.stringify({ state: "idle" }),
    });
  }

  async destroySession(session: AvatarSessionHandle): Promise<void> {
    await this.fetch(`/sessions/${session.sessionId}`, { method: "DELETE" });
  }

  private async fetch(path: string, init: RequestInit): Promise<Response> {
    let res: Response;
    try {
      res = await fetch(`${ANAM_API_BASE}${path}`, {
        ...init,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
          ...init.headers,
        },
      });
    } catch (err) {
      // Network-level failure — recoverable, caller should fall back
      // (see providerFactory's withFallback wrapper).
      throw new AvatarProviderError(`Anam request failed: ${(err as Error).message}`, this.name, true);
    }

    if (!res.ok) {
      const body = await res.text().catch(() => "");
      const recoverable = res.status >= 500 || res.status === 429;
      throw new AvatarProviderError(`Anam API ${res.status}: ${body}`, this.name, recoverable);
    }

    return res;
  }
}
