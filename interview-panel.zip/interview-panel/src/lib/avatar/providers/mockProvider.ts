import type {
  AvatarPersonaRequest,
  AvatarProvider,
  AvatarSessionHandle,
  SpeakOptions,
} from "../types";

/**
 * No external calls. Used automatically when AVATAR_PROVIDER=mock (the
 * default) or when no real provider key is configured, so the full
 * interview flow — question asking, follow-ups, transcription, coaching —
 * can be built and demoed without a live avatar vendor contract. The
 * client-side player renders this as a CSS-animated portrait (idle sway,
 * blink loop, a simple viseme-less "talking" pulse keyed off `speak`
 * start/stop events delivered over the same session channel a real
 * provider would use) rather than static images, per section 7 — it is a
 * development stand-in for the animation state machine, not a
 * user-facing substitute for the real requirement.
 */
export class MockAvatarProvider implements AvatarProvider {
  readonly name = "mock";

  async createSession(persona: AvatarPersonaRequest): Promise<AvatarSessionHandle> {
    return {
      sessionId: `mock_${persona.interviewerId}_${Date.now()}`,
      interviewerId: persona.interviewerId,
      connectionInfo: { mode: "mock", persona },
    };
  }

  async loadAvatar(): Promise<void> {
    // no-op: the mock player renders immediately client-side
  }

  async speak(_session: AvatarSessionHandle, _options: SpeakOptions): Promise<void> {
    // no-op server-side; the interview room emits a client-side "speaking"
    // state and plays the TTS audio directly, driving the mock avatar's
    // CSS mouth-pulse animation off audio playback events.
  }

  async stopSpeaking(): Promise<void> {}
  async setListeningState(): Promise<void> {}
  async setIdleState(): Promise<void> {}
  async destroySession(): Promise<void> {}
}
