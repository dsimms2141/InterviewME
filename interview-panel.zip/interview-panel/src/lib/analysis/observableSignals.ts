import type { ObservableSignals } from "@/types/domain";

// Deterministic, non-LLM analysis of observable communication characteristics
// (section 16). Runs locally on the transcript + duration — never claims to
// infer truthfulness, intelligence, personality, or any protected
// characteristic. Filler-word and pacing counts are the only signals used
// for coaching; nothing here touches the candidate's camera feed.

const FILLER_WORDS = [
  "um",
  "uh",
  "like",
  "you know",
  "sort of",
  "kind of",
  "basically",
  "actually",
  "i mean",
  "right?",
];

export function analyzeObservableSignals(input: {
  transcript: string;
  durationSeconds: number;
}): ObservableSignals {
  const words = input.transcript.trim().split(/\s+/).filter(Boolean);
  const wordCount = words.length;
  const minutes = Math.max(input.durationSeconds / 60, 1 / 60);
  const speakingPaceWpm = Math.round(wordCount / minutes);

  const lowerTranscript = input.transcript.toLowerCase();
  const fillerWordCount = FILLER_WORDS.reduce((count, filler) => {
    const pattern = new RegExp(`\\b${filler.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\b`, "g");
    const matches = lowerTranscript.match(pattern);
    return count + (matches?.length ?? 0);
  }, 0);

  // Long pauses aren't observable from a plain transcript; when the STT
  // provider emits word-level timestamps this should be replaced with a
  // real gap-detection pass. Estimated here as 0 until that's wired up.
  const longPauseCount = 0;

  const starDetected = detectStarStructure(input.transcript);

  return {
    speakingPaceWpm,
    fillerWordCount,
    longPauseCount,
    durationSeconds: input.durationSeconds,
    starDetected,
  };
}

function detectStarStructure(transcript: string): boolean {
  const lower = transcript.toLowerCase();
  const hasSituation = /\b(situation|when i|at my|while working|during)\b/.test(lower);
  const hasAction = /\b(i decided|i implemented|i led|i created|i built|i organized|i took)\b/.test(lower);
  const hasResult = /\b(as a result|the outcome|this resulted|we achieved|increased|decreased|reduced|improved|%)\b/.test(
    lower
  );
  return hasSituation && hasAction && hasResult;
}
