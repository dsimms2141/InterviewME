// Section 22 (progress tracking): turns raw Response rows into the
// dashboard's trend indicators. Deliberately stays descriptive
// ("average answer length", "filler word trend") — never converted into an
// employment-eligibility score, per the same section's explicit warning.

interface ResponseLike {
  durationSeconds: number | null;
  fillerWordCount: number | null;
  starDetected: boolean | null;
  createdAt: Date;
}

export interface PerformanceTrends {
  interviewsAnswered: number;
  averageAnswerLengthSeconds: number | null;
  fillerWordTrend: "improving" | "steady" | "increasing" | "not enough data";
  starStructureTrend: "improving" | "steady" | "declining" | "not enough data";
}

export function computePerformanceTrends(responses: ResponseLike[]): PerformanceTrends {
  if (responses.length === 0) {
    return {
      interviewsAnswered: 0,
      averageAnswerLengthSeconds: null,
      fillerWordTrend: "not enough data",
      starStructureTrend: "not enough data",
    };
  }

  const durations = responses.map((r) => r.durationSeconds ?? 0).filter((d) => d > 0);
  const averageAnswerLengthSeconds =
    durations.length > 0 ? Math.round(durations.reduce((a, b) => a + b, 0) / durations.length) : null;

  // Compare the first half of answers to the second half to get a simple
  // improving/steady/declining trend without needing a large sample.
  const half = Math.floor(responses.length / 2);
  const earlier = responses.slice(0, half);
  const later = responses.slice(half);

  const fillerWordTrend: PerformanceTrends["fillerWordTrend"] =
    earlier.length < 2 || later.length < 2
      ? "not enough data"
      : compareTrend(avg(earlier, (r) => r.fillerWordCount ?? 0), avg(later, (r) => r.fillerWordCount ?? 0), {
          lowerIsBetter: true,
          worseLabel: "increasing",
        });

  const starStructureTrend: PerformanceTrends["starStructureTrend"] =
    earlier.length < 2 || later.length < 2
      ? "not enough data"
      : compareTrend(
          avg(earlier, (r) => (r.starDetected ? 1 : 0)),
          avg(later, (r) => (r.starDetected ? 1 : 0)),
          { lowerIsBetter: false, worseLabel: "declining" }
        );

  return {
    interviewsAnswered: responses.length,
    averageAnswerLengthSeconds,
    fillerWordTrend,
    starStructureTrend,
  };
}

function avg<T>(items: T[], select: (item: T) => number): number {
  return items.reduce((sum, item) => sum + select(item), 0) / items.length;
}

function compareTrend<WorseLabel extends string>(
  before: number,
  after: number,
  { lowerIsBetter, worseLabel }: { lowerIsBetter: boolean; worseLabel: WorseLabel }
): "improving" | "steady" | WorseLabel {
  const delta = after - before;
  const threshold = Math.max(0.15, Math.abs(before) * 0.1);
  if (Math.abs(delta) < threshold) return "steady";
  const better = lowerIsBetter ? delta < 0 : delta > 0;
  return better ? "improving" : worseLabel;
}
