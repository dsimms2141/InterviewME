import type { JobProfile } from "@prisma/client";
import type { CompetencyProfile } from "@/types/domain";

const asStringArray = (value: unknown): string[] => (Array.isArray(value) ? (value as string[]) : []);

export function toCompetencyProfile(profile: JobProfile): CompetencyProfile {
  return {
    industry: profile.industry ?? "General",
    seniority: profile.seniority ?? "Individual contributor",
    responsibilities: asStringArray(profile.responsibilities),
    requiredSkills: asStringArray(profile.requiredSkills),
    leadershipExpectations: asStringArray(profile.leadershipExpectations),
    technicalCompetencies: asStringArray(profile.technicalCompetencies),
    behavioralCompetencies: asStringArray(profile.behavioralCompetencies),
    customerResponsibilities: asStringArray(profile.customerResponsibilities),
    problemSolvingExpectations: asStringArray(profile.problemSolvingExpectations),
    communicationRequirements: asStringArray(profile.communicationRequirements),
    managementExpectations: asStringArray(profile.managementExpectations),
    relevantTerminology: asStringArray(profile.relevantTerminology),
  };
}
