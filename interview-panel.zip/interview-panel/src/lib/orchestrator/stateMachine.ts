// Central interview state machine (section 35). Enforced server-side so
// only one interviewer ever has speaking control and the client can't skip
// states by racing requests.

export type InterviewState =
  | "SETUP"
  | "PANEL_GENERATION"
  | "DEVICE_CHECK"
  | "WAITING_ROOM"
  | "INTRODUCTION"
  | "ASKING_QUESTION"
  | "CANDIDATE_RESPONDING"
  | "ANALYZING_RESPONSE"
  | "FOLLOW_UP"
  | "NEXT_QUESTION"
  | "CLOSING"
  | "GENERATING_FEEDBACK"
  | "COMPLETE"
  | "ABANDONED";

const TRANSITIONS: Record<InterviewState, InterviewState[]> = {
  SETUP: ["PANEL_GENERATION", "ABANDONED"],
  PANEL_GENERATION: ["DEVICE_CHECK", "ABANDONED"],
  DEVICE_CHECK: ["WAITING_ROOM", "ABANDONED"],
  WAITING_ROOM: ["INTRODUCTION", "ABANDONED"],
  INTRODUCTION: ["ASKING_QUESTION", "ABANDONED"],
  ASKING_QUESTION: ["CANDIDATE_RESPONDING", "ABANDONED"],
  CANDIDATE_RESPONDING: ["ANALYZING_RESPONSE", "ABANDONED"],
  ANALYZING_RESPONSE: ["FOLLOW_UP", "NEXT_QUESTION", "ABANDONED"],
  FOLLOW_UP: ["CANDIDATE_RESPONDING", "ABANDONED"],
  NEXT_QUESTION: ["ASKING_QUESTION", "CLOSING", "ABANDONED"],
  CLOSING: ["GENERATING_FEEDBACK", "ABANDONED"],
  GENERATING_FEEDBACK: ["COMPLETE", "ABANDONED"],
  COMPLETE: [],
  ABANDONED: [],
};

export function canTransition(from: InterviewState, to: InterviewState): boolean {
  return TRANSITIONS[from]?.includes(to) ?? false;
}

export function assertTransition(from: InterviewState, to: InterviewState): void {
  if (!canTransition(from, to)) {
    throw new Error(`Illegal interview state transition: ${from} -> ${to}`);
  }
}

/** Only one interviewer speaks at a time; this derives who (if anyone)
 *  currently has the floor from the session state, for the UI to enforce
 *  "the other two remain in listening/idle states" (section 2). */
export function speakingSeatFor(state: InterviewState, activeSeat: 1 | 2 | 3 | null): (1 | 2 | 3) | null {
  const speakingStates: InterviewState[] = ["INTRODUCTION", "ASKING_QUESTION", "FOLLOW_UP", "CLOSING"];
  return speakingStates.includes(state) ? activeSeat : null;
}
