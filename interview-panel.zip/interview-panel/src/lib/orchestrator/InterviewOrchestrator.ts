import { db } from "@/lib/db";
import type { Prisma } from "@prisma/client";
import { assertTransition, type InterviewState } from "./stateMachine";
import { decideFollowUp } from "@/lib/llm/followUp";
import { evaluateResponse } from "@/lib/llm/coaching";
import { analyzeObservableSignals } from "@/lib/analysis/observableSignals";
import { generateReadinessReport } from "@/lib/llm/readinessReport";
import { generatePlaybook } from "@/lib/llm/playbook";
import type { CompetencyProfile, InterviewMode, QuestionEvaluation } from "@/types/domain";

const MAX_FOLLOW_UPS_PER_QUESTION = 2;

/**
 * Drives one interview session through the state machine. Every mutating
 * call goes through here rather than letting API routes touch
 * InterviewSession.state directly, so the "only one interviewer speaks at a
 * time" and "no illegal transition" rules (section 35) are enforced in one
 * place.
 */
export class InterviewOrchestrator {
  constructor(private readonly sessionId: string) {}

  private async setState(to: InterviewState) {
    const session = await db.interviewSession.findUniqueOrThrow({ where: { id: this.sessionId } });
    assertTransition(session.state as InterviewState, to);
    await db.interviewSession.update({ where: { id: this.sessionId }, data: { state: to } });
  }

  async beginIntroduction() {
    await this.setState("WAITING_ROOM");
    await this.setState("INTRODUCTION");
  }

  async askQuestion(questionId: string) {
    await this.setState("ASKING_QUESTION");
    await db.interviewSession.update({
      where: { id: this.sessionId },
      data: { state: "CANDIDATE_RESPONDING" },
    });
  }

  /**
   * Called once the candidate's answer has been transcribed. Runs
   * observable-signal analysis + coaching, then decides (via the LLM) and
   * returns whether a follow-up should be asked next, respecting the
   * per-question follow-up cap so interviews stay bounded (section 13).
   */
  async processAnswer(input: {
    responseId: string;
    questionId: string;
    questionText: string;
    testingFor: string;
    transcript: string;
    durationSeconds: number;
    mode: InterviewMode;
  }) {
    await this.setState("ANALYZING_RESPONSE");

    const signals = analyzeObservableSignals({
      transcript: input.transcript,
      durationSeconds: input.durationSeconds,
    });

    await db.response.update({
      where: { id: input.responseId },
      data: {
        speakingPaceWpm: signals.speakingPaceWpm,
        fillerWordCount: signals.fillerWordCount,
        longPauseCount: signals.longPauseCount,
        starDetected: signals.starDetected,
      },
    });

    const priorFollowUpCount = await db.response.count({
      where: { questionId: input.questionId, isFollowUp: true },
    });

    if (priorFollowUpCount >= MAX_FOLLOW_UPS_PER_QUESTION) {
      await this.setState("NEXT_QUESTION");
      return { followUp: null };
    }

    const decision = await decideFollowUp({
      questionText: input.questionText,
      candidateAnswer: input.transcript,
      mode: input.mode,
      priorFollowUpCount,
    });

    if (decision.shouldFollowUp && decision.followUpQuestion) {
      await this.setState("FOLLOW_UP");
      return { followUp: decision.followUpQuestion };
    }

    await this.setState("NEXT_QUESTION");
    return { followUp: null };
  }

  async advanceOrClose(hasMoreQuestions: boolean) {
    if (hasMoreQuestions) {
      await this.setState("ASKING_QUESTION");
    } else {
      await this.setState("CLOSING");
    }
  }

  /**
   * Runs the full coaching pipeline (sections 18-20): per-answer evaluation,
   * an overall readiness report, and the saved interview playbook. Marks the
   * session COMPLETE once persisted.
   */
  async generateFeedback(jobTitle: string, competencyProfile: CompetencyProfile) {
    await this.setState("GENERATING_FEEDBACK");

    const session = await db.interviewSession.findUniqueOrThrow({
      where: { id: this.sessionId },
      include: { responses: { include: { question: true }, orderBy: { createdAt: "asc" } } },
    });

    const evaluations: QuestionEvaluation[] = [];
    const followUpEvaluations: QuestionEvaluation[] = [];

    const evaluation = await db.evaluation.create({
      data: {
        interviewSessionId: this.sessionId,
        overallSummary: "",
        answerStructureLevel: "DEVELOPING",
        relevanceLevel: "DEVELOPING",
        specificityLevel: "DEVELOPING",
        problemSolvingLevel: "DEVELOPING",
        communicationLevel: "DEVELOPING",
        starUsageLevel: "DEVELOPING",
        concisenessLevel: "DEVELOPING",
        roleKnowledgeLevel: "DEVELOPING",
        strengths: [],
        growthAreas: [],
      },
    });

    for (const response of session.responses) {
      const result = await evaluateResponse({
        questionText: response.question.text,
        testingFor: response.question.testingFor ?? "",
        transcript: response.transcript,
        signals: {
          speakingPaceWpm: response.speakingPaceWpm ?? 0,
          fillerWordCount: response.fillerWordCount ?? 0,
          starDetected: response.starDetected ?? false,
        },
      });

      (response.isFollowUp ? followUpEvaluations : evaluations).push(result);

      await db.evaluationItem.create({
        data: {
          evaluationId: evaluation.id,
          responseId: response.id,
          whatWorked: result.whatWorked,
          whatCouldBeStronger: result.whatCouldBeStronger,
          whatQuestionTested: result.whatQuestionTested,
          missingInformation: result.missingInformation,
          starSituation: result.star.situation,
          starTask: result.star.task,
          starAction: result.star.action,
          starResult: result.star.result,
          betterAnswerStructure: result.betterAnswerStructure,
          coachingNotes: result.coachingNotes,
          practiceRecommendation: result.practiceRecommendation,
        },
      });
    }

    const readiness = await generateReadinessReport({ jobTitle, evaluations });

    await db.evaluation.update({
      where: { id: evaluation.id },
      data: {
        overallSummary: readiness.overallSummary,
        answerStructureLevel: readiness.levels.answerStructure,
        relevanceLevel: readiness.levels.relevance,
        specificityLevel: readiness.levels.specificity,
        problemSolvingLevel: readiness.levels.problemSolving,
        communicationLevel: readiness.levels.communication,
        starUsageLevel: readiness.levels.starUsage,
        concisenessLevel: readiness.levels.conciseness,
        roleKnowledgeLevel: readiness.levels.roleKnowledge,
        strengths: readiness.strengths,
        growthAreas: readiness.growthAreas,
      },
    });

    const playbookContent = await generatePlaybook({
      jobTitle,
      competencyProfile,
      evaluations,
      followUpEvaluations,
      readinessReport: readiness,
    });

    await db.playbook.create({
      data: {
        interviewSessionId: this.sessionId,
        content: playbookContent as unknown as Prisma.InputJsonValue,
      },
    });

    await db.interviewSession.update({
      where: { id: this.sessionId },
      data: { state: "COMPLETE", completionStatus: "COMPLETED", endTime: new Date() },
    });
  }
}
