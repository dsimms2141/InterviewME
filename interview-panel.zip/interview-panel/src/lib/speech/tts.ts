// Text-to-speech abstraction. Called by the orchestrator before handing
// audio to the avatar provider's speak() (audio-passthrough mode), so the
// avatar vendor and the voice vendor can be swapped independently.

export interface TtsResult {
  audioBase64: string;
  mimeType: string;
}

export interface TtsProvider {
  readonly name: string;
  synthesize(input: { text: string; voiceId: string }): Promise<TtsResult>;
}

class ElevenLabsTtsProvider implements TtsProvider {
  readonly name = "elevenlabs";
  constructor(private readonly apiKey: string) {}

  async synthesize(input: { text: string; voiceId: string }): Promise<TtsResult> {
    const res = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${input.voiceId}`, {
      method: "POST",
      headers: {
        "xi-api-key": this.apiKey,
        "Content-Type": "application/json",
        Accept: "audio/mpeg",
      },
      body: JSON.stringify({
        text: input.text,
        model_id: "eleven_turbo_v2",
      }),
    });

    if (!res.ok) {
      throw new Error(`ElevenLabs TTS failed: ${res.status} ${await res.text().catch(() => "")}`);
    }

    const buffer = Buffer.from(await res.arrayBuffer());
    return { audioBase64: buffer.toString("base64"), mimeType: "audio/mpeg" };
  }
}

/**
 * Silent stand-in used when no TTS key is configured, so the orchestrator
 * and avatar pipeline can run end-to-end in development. The interview room
 * falls back to on-screen captions only when this provider is active.
 */
class SilentTtsProvider implements TtsProvider {
  readonly name = "silent";
  async synthesize(): Promise<TtsResult> {
    return { audioBase64: "", mimeType: "audio/mpeg" };
  }
}

let cached: TtsProvider | null = null;

export function getTtsProvider(): TtsProvider {
  if (cached) return cached;
  const apiKey = process.env.ELEVENLABS_API_KEY;
  cached = apiKey ? new ElevenLabsTtsProvider(apiKey) : new SilentTtsProvider();
  return cached;
}
