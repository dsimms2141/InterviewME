// Speech-to-text abstraction. The interview room primarily uses the
// browser's own SpeechRecognition API for low-latency live captions and
// candidate-finished-speaking detection (no server round-trip needed for
// that). This server-side transcriber is the source of truth written to
// Response.transcript: the candidate's answer audio (or the live
// browser transcript, when audio retention is disabled) is sent here once
// the candidate finishes, so coaching always runs against a
// provider-transcribed transcript rather than the possibly-lower-quality
// live browser one.

export interface SttProvider {
  readonly name: string;
  transcribe(input: { audioBase64: string; mimeType: string }): Promise<{ transcript: string }>;
}

class DeepgramSttProvider implements SttProvider {
  readonly name = "deepgram";
  constructor(private readonly apiKey: string) {}

  async transcribe(input: { audioBase64: string; mimeType: string }): Promise<{ transcript: string }> {
    const audio = Buffer.from(input.audioBase64, "base64");

    const res = await fetch("https://api.deepgram.com/v1/listen?smart_format=true&punctuate=true", {
      method: "POST",
      headers: {
        Authorization: `Token ${this.apiKey}`,
        "Content-Type": input.mimeType,
      },
      body: audio,
    });

    if (!res.ok) {
      throw new Error(`Deepgram STT failed: ${res.status} ${await res.text().catch(() => "")}`);
    }

    const data = (await res.json()) as {
      results: { channels: { alternatives: { transcript: string }[] }[] };
    };

    const transcript = data.results.channels[0]?.alternatives[0]?.transcript ?? "";
    return { transcript };
  }
}

/**
 * Used when no STT key is configured. Passes through whatever transcript
 * the client already captured via the browser's SpeechRecognition API,
 * so the app still functions end-to-end in development without a paid key.
 */
class PassthroughSttProvider implements SttProvider {
  readonly name = "passthrough";
  async transcribe(input: { audioBase64: string; mimeType: string }): Promise<{ transcript: string }> {
    void input;
    return { transcript: "" };
  }
}

let cached: SttProvider | null = null;

export function getSttProvider(): SttProvider {
  if (cached) return cached;
  const apiKey = process.env.DEEPGRAM_API_KEY;
  cached = apiKey ? new DeepgramSttProvider(apiKey) : new PassthroughSttProvider();
  return cached;
}
