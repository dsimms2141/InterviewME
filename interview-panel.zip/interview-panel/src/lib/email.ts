// Minimal transactional email wrapper. Resend is the default provider — a
// plain REST call, so no SDK dependency is needed. When RESEND_API_KEY
// isn't set (e.g. local development), send() logs the message instead of
// throwing, so the rest of the app (password reset, in particular) keeps
// working without an email provider configured.

export interface EmailMessage {
  to: string;
  subject: string;
  html: string;
}

export async function sendEmail(message: EmailMessage): Promise<{ sent: boolean }> {
  const apiKey = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "Panel Ready <onboarding@resend.dev>";

  if (!apiKey) {
    console.warn(
      `[email] RESEND_API_KEY not set — would have sent "${message.subject}" to ${message.to}. ` +
        "Set RESEND_API_KEY (and EMAIL_FROM) in .env to send real email."
    );
    return { sent: false };
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from,
      to: message.to,
      subject: message.subject,
      html: message.html,
    }),
  });

  if (!res.ok) {
    console.error(`[email] Resend send failed: ${res.status} ${await res.text().catch(() => "")}`);
    return { sent: false };
  }

  return { sent: true };
}

export function passwordResetEmail(resetUrl: string): { subject: string; html: string } {
  return {
    subject: "Reset your Panel Ready password",
    html: `
      <p>We received a request to reset your Panel Ready password.</p>
      <p><a href="${resetUrl}">Click here to choose a new password</a>. This link expires in 30 minutes.</p>
      <p>If you didn't request this, you can safely ignore this email.</p>
    `.trim(),
  };
}
