import { db } from "@/lib/db";

// Section 32 (cost architecture): records provider usage so avatar minutes,
// STT/TTS usage, LLM tokens, and storage can be tracked per session and
// rolled up for the dashboard/analytics without re-deriving it from raw
// provider invoices later.

const ESTIMATED_UNIT_COST_USD: Record<string, number> = {
  avatar_minutes: 0.14, // blended self-serve rate; override once a vendor contract is signed
  stt_minutes: 0.006,
  tts_characters: 0.00003,
  llm_tokens: 0.000003,
  storage_mb: 0.00002,
};

export async function recordUsage(input: {
  interviewSessionId?: string;
  userId?: string;
  kind: "AVATAR_MINUTES" | "STT_MINUTES" | "TTS_CHARACTERS" | "LLM_TOKENS" | "STORAGE";
  quantity: number;
  unit: keyof typeof ESTIMATED_UNIT_COST_USD;
  provider: string;
}) {
  const costUsdEstimate = ESTIMATED_UNIT_COST_USD[input.unit] * input.quantity;

  await db.usageEvent.create({
    data: {
      interviewSessionId: input.interviewSessionId,
      userId: input.userId,
      kind: input.kind,
      quantity: input.quantity,
      unit: input.unit,
      provider: input.provider,
      costUsdEstimate,
    },
  });
}
