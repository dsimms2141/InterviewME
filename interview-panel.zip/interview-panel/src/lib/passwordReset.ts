import { randomBytes, createHash } from "crypto";
import { db } from "@/lib/db";

const TOKEN_TTL_MS = 1000 * 60 * 30; // 30 minutes

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/**
 * Issues a password-reset token for the given email if an account exists.
 * Always returns successfully (no "does that email exist" oracle) — the
 * caller decides what to do with the raw token (email it, or in
 * development, log/return it since no email provider is wired up yet; see
 * docs/ARCHITECTURE.md's "explicitly stubbed" list).
 */
export async function createPasswordResetToken(email: string): Promise<string | null> {
  const user = await db.user.findUnique({ where: { email: email.toLowerCase() } });
  if (!user) return null;

  const rawToken = randomBytes(32).toString("hex");
  await db.passwordResetToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(rawToken),
      expiresAt: new Date(Date.now() + TOKEN_TTL_MS),
    },
  });

  return rawToken;
}

export async function consumePasswordResetToken(rawToken: string): Promise<string | null> {
  const tokenHash = hashToken(rawToken);
  const record = await db.passwordResetToken.findUnique({ where: { tokenHash } });

  if (!record || record.usedAt || record.expiresAt < new Date()) {
    return null;
  }

  await db.passwordResetToken.update({ where: { id: record.id }, data: { usedAt: new Date() } });
  return record.userId;
}
