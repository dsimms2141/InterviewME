// Recording storage abstraction (section 24: "capable of analyzing/
// transcribing a session without permanently retaining raw video/audio when
// technically feasible"). Only called when the candidate's UserSettings
// opts into retention — see respond/route.ts, which checks
// `saveAudioRecordings` before ever calling this.

export interface StoredAudio {
  url: string;
}

let s3Client: import("@aws-sdk/client-s3").S3Client | null = null;

async function getS3Client() {
  if (s3Client) return s3Client;
  const { S3Client } = await import("@aws-sdk/client-s3");
  s3Client = new S3Client({ region: process.env.S3_REGION });
  return s3Client;
}

/**
 * Uploads one candidate answer's audio to S3 and returns its URL. Returns
 * null (and logs a warning) when S3 isn't configured, so `/respond` can
 * degrade to "transcribed, not retained" rather than failing the request —
 * consistent with retention being an opt-in feature, not a hard dependency.
 */
export async function uploadResponseAudio(input: {
  interviewSessionId: string;
  responseId: string;
  audioBase64: string;
  mimeType: string;
}): Promise<StoredAudio | null> {
  const bucket = process.env.S3_BUCKET;
  if (!bucket || process.env.DISABLE_VIDEO_RECORDING === "true") {
    return null;
  }

  const { PutObjectCommand } = await import("@aws-sdk/client-s3");
  const client = await getS3Client();

  const extension = input.mimeType.includes("webm") ? "webm" : input.mimeType.includes("mp4") ? "mp4" : "audio";
  const key = `recordings/${input.interviewSessionId}/${input.responseId}.${extension}`;

  await client.send(
    new PutObjectCommand({
      Bucket: bucket,
      Key: key,
      Body: Buffer.from(input.audioBase64, "base64"),
      ContentType: input.mimeType,
    })
  );

  return { url: `https://${bucket}.s3.${process.env.S3_REGION}.amazonaws.com/${key}` };
}

/** Deletes one response's stored audio object, if any. Used by the
 *  "Delete recordings" action (DELETE /api/interview-sessions/[id]/recording). */
export async function deleteResponseAudio(audioUrl: string): Promise<void> {
  const bucket = process.env.S3_BUCKET;
  if (!bucket) return;

  const key = audioUrl.split(`.amazonaws.com/`)[1];
  if (!key) return;

  const { DeleteObjectCommand } = await import("@aws-sdk/client-s3");
  const client = await getS3Client();
  await client.send(new DeleteObjectCommand({ Bucket: bucket, Key: key }));
}
