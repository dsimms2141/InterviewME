"use client";

export function PrintButton() {
  return (
    <button
      onClick={() => window.print()}
      className="rounded-md border border-panel-border px-4 py-2 text-sm hover:border-brand-500"
    >
      Print / Export
    </button>
  );
}
