"use client";

import Link from "next/link";
import { signOut } from "next-auth/react";

export function NavBar() {
  return (
    <header className="border-b border-panel-border bg-panel-bg/80 backdrop-blur">
      <div className="mx-auto flex max-w-6xl items-center justify-between px-6 py-3">
        <Link href="/dashboard" className="font-semibold">
          Panel Ready
        </Link>
        <nav className="flex items-center gap-5 text-sm text-slate-400">
          <Link href="/dashboard/jobs" className="hover:text-slate-200">
            Saved jobs
          </Link>
          <Link href="/dashboard/settings" className="hover:text-slate-200">
            Settings
          </Link>
          <button onClick={() => signOut({ callbackUrl: "/" })} className="hover:text-slate-200">
            Sign out
          </button>
        </nav>
      </div>
    </header>
  );
}
