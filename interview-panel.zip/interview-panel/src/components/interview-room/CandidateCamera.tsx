"use client";

import { forwardRef } from "react";

export const CandidateCamera = forwardRef<HTMLVideoElement, { micActive: boolean; recording: boolean }>(
  function CandidateCamera({ micActive, recording }, ref) {
    return (
      <div className="relative overflow-hidden rounded-xl border border-panel-border bg-black">
        <video ref={ref} autoPlay muted playsInline className="aspect-video w-full object-cover" />
        <div className="absolute bottom-3 left-3 flex items-center gap-2">
          <span className={`h-2 w-2 rounded-full ${micActive ? "bg-emerald-500" : "bg-slate-500"}`} />
          <span className="text-xs text-slate-300">{micActive ? "Mic on" : "Mic muted"}</span>
        </div>
        {recording && (
          <div className="absolute right-3 top-3 flex items-center gap-1.5 rounded-full bg-black/60 px-2.5 py-1 text-xs text-red-400">
            <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-red-500" />
            Recording
          </div>
        )}
      </div>
    );
  }
);
