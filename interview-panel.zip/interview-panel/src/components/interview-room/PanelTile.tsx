"use client";

import type { AvatarState } from "@/lib/avatar/types";

export interface PanelTileData {
  seatOrder: 1 | 2 | 3;
  firstName: string;
  lastName: string;
  title: string;
  appearanceSeed: {
    genderPresentation: "masculine" | "feminine" | "androgynous";
    agePresentation: "younger" | "mid-career" | "senior";
    skinTone: string;
    hairstyle: string;
    attire: string;
  };
}

const SKIN_TONE_FALLBACK: Record<string, string> = {
  default: "#c68863",
};

/**
 * Renders one panelist. In production (AVATAR_PROVIDER=anam/heygen_liveavatar)
 * this tile hosts the vendor's WebRTC video track instead of the CSS
 * placeholder below — the `avatarState` prop and the state machine driving
 * it stay identical either way, which is the point of the AvatarProvider
 * seam (see lib/avatar/types.ts): swapping in a real video element here
 * does not touch the orchestration logic.
 */
export function PanelTile({ data, avatarState }: { data: PanelTileData; avatarState: AvatarState }) {
  const isSpeaking = avatarState === "SPEAKING";
  const isThinking = avatarState === "THINKING";

  return (
    <div
      className={`relative flex flex-col overflow-hidden rounded-xl border bg-panel-surface transition ${
        isSpeaking ? "border-brand-500 shadow-[0_0_0_1px_rgba(61,99,224,0.4)]" : "border-panel-border"
      }`}
    >
      <div className="relative flex aspect-[4/3] items-center justify-center bg-[#0d1526]">
        <div className={`avatar-idle flex flex-col items-center ${isThinking ? "opacity-80" : ""}`}>
          <div
            className="avatar-blink relative flex h-28 w-28 items-center justify-center rounded-full text-3xl font-semibold text-white sm:h-32 sm:w-32"
            style={{ backgroundColor: SKIN_TONE_FALLBACK.default }}
          >
            {data.firstName[0]}
            {data.lastName[0]}
            <span
              className={`absolute bottom-6 h-2 w-8 rounded-full bg-black/40 ${
                isSpeaking ? "avatar-mouth-speaking" : ""
              }`}
            />
          </div>
        </div>

        {isThinking && (
          <span className="absolute bottom-3 right-3 rounded-full bg-black/50 px-2 py-1 text-xs text-slate-300">
            thinking...
          </span>
        )}
      </div>

      <div className="flex items-center justify-between gap-2 px-3 py-2.5">
        <div>
          <p className="text-sm font-medium leading-none">
            {data.firstName} {data.lastName}
          </p>
          <p className="mt-1 text-xs text-slate-400">{data.title}</p>
        </div>
        <StateBadge state={avatarState} />
      </div>
    </div>
  );
}

function StateBadge({ state }: { state: AvatarState }) {
  const label =
    state === "SPEAKING"
      ? "Speaking"
      : state === "LISTENING"
        ? "Listening"
        : state === "THINKING"
          ? "Thinking"
          : "";
  if (!label) return null;
  const color = state === "SPEAKING" ? "bg-brand-500" : "bg-slate-600";
  return <span className={`rounded-full ${color} px-2 py-0.5 text-[10px] uppercase tracking-wide text-white`}>{label}</span>;
}
