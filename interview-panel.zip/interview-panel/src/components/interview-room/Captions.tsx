"use client";

export function Captions({ text, visible }: { text: string; visible: boolean }) {
  if (!visible || !text) return null;
  return (
    <div className="mx-auto max-w-3xl rounded-lg bg-black/60 px-4 py-2 text-center text-sm text-slate-100">
      {text}
    </div>
  );
}
