"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { PanelTile, type PanelTileData } from "./PanelTile";
import { CandidateCamera } from "./CandidateCamera";
import { Controls } from "./Controls";
import { Captions } from "./Captions";
import type { AvatarState } from "@/lib/avatar/types";

interface SessionData {
  id: string;
  mode: "PRACTICE" | "REALISTIC" | "PRESSURE";
  jobProfile: { title: string };
  panel: {
    seatOrder: number;
    interviewerId: string;
    interviewer: Omit<PanelTileData, "seatOrder"> & { id: string };
  }[];
  questions: {
    id: string;
    order: number;
    text: string;
    interviewerId: string | null;
  }[];
}

type Phase = "loading" | "introduction" | "asking" | "listening" | "processing" | "closing" | "complete";

// How long the candidate must go without new recognized speech before we
// auto-submit their answer. Kept generous per section 14: "Do not interrupt
// candidates simply because they pause briefly" — this is a long-silence
// safety net, not a turn-taking timer. The manual "Finished answer" button
// (Controls.tsx) is always available and is the primary control either way.
const AUTO_SILENCE_MS = 4500;
// Minimum time listening before auto-silence can fire at all, so a slow
// mic/recognition startup can't trigger an instant auto-submit.
const MIN_LISTEN_MS_BEFORE_AUTO_SUBMIT = 3000;

// Minimal ambient type for the browser SpeechRecognition API, which has no
// official TS lib entry yet and ships under a vendor prefix in Chromium.
interface SpeechRecognitionLike extends EventTarget {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  start(): void;
  stop(): void;
  onresult: ((event: unknown) => void) | null;
  onerror: ((event: unknown) => void) | null;
  onend: (() => void) | null;
}

export function InterviewRoomClient({ sessionId }: { sessionId: string }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const forcedTextMode = searchParams.get("mode") === "text";
  const videoRef = useRef<HTMLVideoElement>(null);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const recognitionRef = useRef<SpeechRecognitionLike | null>(null);

  const [session, setSession] = useState<SessionData | null>(null);
  const [phase, setPhase] = useState<Phase>("loading");
  const [questionIndex, setQuestionIndex] = useState(0);
  const [activeSeat, setActiveSeat] = useState<1 | 2 | 3 | null>(null);
  const [avatarStates, setAvatarStates] = useState<Record<1 | 2 | 3, AvatarState>>({
    1: "IDLE",
    2: "IDLE",
    3: "IDLE",
  });
  const [caption, setCaption] = useState("");
  const [captionsVisible, setCaptionsVisible] = useState(false);
  const [micOn, setMicOn] = useState(true);
  const [liveTranscript, setLiveTranscript] = useState("");
  const [answerStartedAt, setAnswerStartedAt] = useState<number | null>(null);
  const [pendingFollowUp, setPendingFollowUp] = useState<string | null>(null);
  // Accessibility text-response path (section 25): lets a candidate type
  // their answer instead of speaking it — no camera or microphone required
  // for the answer itself. finishAnswer() reads from `typedAnswer` instead
  // of `liveTranscript` whenever this is on.
  const [textMode, setTextMode] = useState(forcedTextMode);
  const [typedAnswer, setTypedAnswer] = useState("");
  const silenceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // ---- Load session + camera -------------------------------------------------

  useEffect(() => {
    fetch(`/api/interview-sessions/${sessionId}`)
      .then((r) => r.json())
      .then((data) => setSession(data.interviewSession))
      .catch(() => setSession(null));
  }, [sessionId]);

  useEffect(() => {
    // Camera-optional accessibility path (section 25): a candidate who
    // skipped camera permission at device check (or whose camera failed
    // here) can still complete the interview — audio-only, or fully via
    // the "Type my answer instead" text path below, with no camera feed
    // ever required to speak with the panel or submit an answer. A
    // candidate who chose the text-only path at device check never has
    // getUserMedia called here at all.
    if (forcedTextMode) return;

    navigator.mediaDevices
      .getUserMedia({ video: true, audio: true })
      .catch(() => navigator.mediaDevices.getUserMedia({ video: false, audio: true }))
      .catch(() => null)
      .then((stream) => {
        if (stream && videoRef.current) videoRef.current.srcObject = stream;
      });
  }, [forcedTextMode]);

  // ---- Speech recognition (live captions + candidate transcript) -------------

  useEffect(() => {
    const SpeechRecognitionCtor =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike })
        .SpeechRecognition ??
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition;
    if (!SpeechRecognitionCtor) return;

    const recognition = new SpeechRecognitionCtor();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";
    recognition.onresult = (event: unknown) => {
      const e = event as { resultIndex: number; results: { [i: number]: { [j: number]: { transcript: string } }; length: number } };
      let finalText = "";
      for (let i = e.resultIndex; i < e.results.length; i++) {
        finalText += e.results[i]?.[0]?.transcript ?? "";
      }
      setLiveTranscript((prev) => (prev + " " + finalText).trim());
    };
    recognitionRef.current = recognition;
  }, []);

  const startListening = useCallback(() => {
    setLiveTranscript("");
    setTypedAnswer("");
    setAnswerStartedAt(Date.now());
    if (textMode) return; // typed answers don't use speech recognition
    try {
      recognitionRef.current?.start();
    } catch {
      // already started — ignore
    }
  }, [textMode]);

  const stopListening = useCallback(() => {
    try {
      recognitionRef.current?.stop();
    } catch {
      // not started — ignore
    }
  }, []);

  // ---- Avatar speaking helper --------------------------------------------------

  const speak = useCallback(async (seat: 1 | 2 | 3, text: string) => {
    setActiveSeat(seat);
    setAvatarStates((prev) => ({ ...prev, [seat]: "SPEAKING" }));
    setCaption(text);

    try {
      const res = await fetch("/api/tts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text, voiceId: `seat-${seat}`, interviewSessionId: sessionId }),
      });
      const data = await res.json();

      if (data.audioBase64) {
        const audio = new Audio(`data:${data.mimeType};base64,${data.audioBase64}`);
        audioPlayerRef.current = audio;
        await new Promise<void>((resolve) => {
          audio.onended = () => resolve();
          audio.onerror = () => resolve();
          audio.play().catch(() => resolve());
        });
      } else {
        // No TTS provider configured (development mode) — estimate a
        // natural speaking duration from word count so the demo flow still
        // feels paced rather than instantaneous.
        const words = text.split(/\s+/).length;
        const ms = Math.max(1200, (words / 2.5) * 1000);
        await new Promise((resolve) => setTimeout(resolve, ms));
      }
    } finally {
      setAvatarStates((prev) => ({ ...prev, [seat]: "IDLE" }));
    }
  }, [sessionId]);

  const setAllListening = useCallback((except?: 1 | 2 | 3) => {
    setAvatarStates({
      1: except === 1 ? "IDLE" : "LISTENING",
      2: except === 2 ? "IDLE" : "LISTENING",
      3: except === 3 ? "IDLE" : "LISTENING",
    });
  }, []);

  // ---- Interview flow ----------------------------------------------------------

  const seatFor = useCallback(
    (interviewerId: string | null): 1 | 2 | 3 => {
      const membership = session?.panel.find((p) => p.interviewerId === interviewerId);
      return (membership?.seatOrder as 1 | 2 | 3) ?? 1;
    },
    [session]
  );

  const runIntroduction = useCallback(async () => {
    if (!session) return;
    setPhase("introduction");
    const [p1, p2, p3] = session.panel;
    if (!p1) return;

    await speak(
      1,
      `Good afternoon. Thank you for meeting with us today. I'm ${p1.interviewer.firstName} ${p1.interviewer.lastName}, ${p1.interviewer.title}.` +
        (p2 && p3
          ? ` Joining me are ${p2.interviewer.firstName} ${p2.interviewer.lastName} and ${p3.interviewer.firstName} ${p3.interviewer.lastName}.`
          : "")
    );
    setAllListening(1);
    await speak(
      1,
      "We'll be asking you several questions regarding your experience, your approach, and how you might respond to situations you could encounter in this role."
    );
    setAllListening(1);
    await speak(1, "Whenever you're ready, we'll begin.");
    setAllListening();
    setPhase("asking");
  }, [session, speak, setAllListening]);

  const askCurrentQuestion = useCallback(async () => {
    if (!session) return;
    const question = session.questions[questionIndex];
    if (!question) {
      setPhase("closing");
      return;
    }
    const seat = seatFor(question.interviewerId);
    setPhase("asking");
    await speak(seat, question.text);
    setAllListening(seat);
    setPhase("listening");
    startListening();
  }, [session, questionIndex, seatFor, speak, setAllListening, startListening]);

  const runClosing = useCallback(async () => {
    if (!session) return;
    setPhase("closing");
    await speak(1, "Thank you. That concludes the questions we have for you today. We appreciate the time you've spent with us.");
    setAllListening();

    await fetch(`/api/interview-sessions/${sessionId}/complete`, { method: "POST" });
    setPhase("complete");
    router.push(`/interview/${sessionId}/feedback`);
  }, [session, speak, setAllListening, sessionId, router]);

  useEffect(() => {
    if (session && phase === "loading") {
      runIntroduction();
    }
  }, [session, phase, runIntroduction]);

  const [readyForFirstQuestion, setReadyForFirstQuestion] = useState(false);
  useEffect(() => {
    if (phase === "asking" && !readyForFirstQuestion) {
      setReadyForFirstQuestion(true);
      askCurrentQuestion();
    }
  }, [phase, readyForFirstQuestion, askCurrentQuestion]);

  const finishAnswer = useCallback(async () => {
    if (!session) return;
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    stopListening();
    setPhase("processing");

    const question = session.questions[questionIndex];
    if (!question) return;

    const durationSeconds = answerStartedAt ? Math.max(1, Math.round((Date.now() - answerStartedAt) / 1000)) : 1;
    const answerText = textMode ? typedAnswer : liveTranscript;

    const res = await fetch(`/api/interview-sessions/${sessionId}/respond`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        questionId: question.id,
        isFollowUp: Boolean(pendingFollowUp),
        followUpText: pendingFollowUp ?? undefined,
        clientTranscript: answerText || "(no answer detected)",
        durationSeconds,
      }),
    });
    const data = await res.json();

    if (data.followUp) {
      setPendingFollowUp(data.followUp);
      const seat = seatFor(question.interviewerId);
      setPhase("asking");
      await speak(seat, data.followUp);
      setAllListening(seat);
      setPhase("listening");
      startListening();
      return;
    }

    setPendingFollowUp(null);
    const nextIndex = questionIndex + 1;
    if (nextIndex < session.questions.length) {
      setQuestionIndex(nextIndex);
      setPhase("asking");
      setReadyForFirstQuestion(false);
    } else {
      runClosing();
    }
  }, [
    session,
    questionIndex,
    answerStartedAt,
    pendingFollowUp,
    liveTranscript,
    typedAnswer,
    textMode,
    sessionId,
    seatFor,
    speak,
    setAllListening,
    startListening,
    stopListening,
    runClosing,
  ]);

  // finishAnswer's identity changes on nearly every dependency, which would
  // otherwise force the silence-timer effect below to tear down and rebuild
  // its timeout on every keystroke of live transcript — a ref keeps "call
  // whatever finishAnswer currently is" stable without that churn.
  const finishAnswerRef = useRef(finishAnswer);
  useEffect(() => {
    finishAnswerRef.current = finishAnswer;
  }, [finishAnswer]);

  // Auto-silence detection (section 14's "candidate finished speaking"
  // signal): once the candidate has said something and then gone quiet for
  // AUTO_SILENCE_MS, submit automatically. The manual "Finished answer"
  // button in Controls remains available throughout and is unaffected by
  // this — this only ever fires in addition to it, never instead of it.
  useEffect(() => {
    if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    if (phase !== "listening" || textMode) return;
    if (!liveTranscript.trim()) return;
    if (!answerStartedAt || Date.now() - answerStartedAt < MIN_LISTEN_MS_BEFORE_AUTO_SUBMIT) return;

    silenceTimerRef.current = setTimeout(() => {
      finishAnswerRef.current();
    }, AUTO_SILENCE_MS);

    return () => {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
    };
  }, [liveTranscript, phase, textMode, answerStartedAt]);

  const toggleMic = useCallback(() => {
    setMicOn((prev) => {
      const next = !prev;
      const stream = videoRef.current?.srcObject as MediaStream | undefined;
      stream?.getAudioTracks().forEach((t) => (t.enabled = next));
      return next;
    });
  }, []);

  const endInterview = useCallback(() => {
    stopListening();
    router.push("/dashboard");
  }, [router, stopListening]);

  const panelTiles = useMemo(() => session?.panel.sort((a, b) => a.seatOrder - b.seatOrder) ?? [], [session]);

  if (!session) {
    return (
      <div className="flex min-h-[60vh] items-center justify-center text-slate-400">Loading your interview room...</div>
    );
  }

  return (
    <div className="flex flex-col gap-5">
      <div className="grid gap-4 sm:grid-cols-3">
        {panelTiles.map((p) => (
          <PanelTile
            key={p.interviewerId}
            data={{ ...p.interviewer, seatOrder: p.seatOrder as 1 | 2 | 3 }}
            avatarState={avatarStates[p.seatOrder as 1 | 2 | 3]}
          />
        ))}
      </div>

      <Captions text={caption} visible={captionsVisible} />

      {!forcedTextMode && (
        <div className="mx-auto w-full max-w-xl">
          <CandidateCamera ref={videoRef} micActive={micOn && phase === "listening"} recording={phase !== "loading"} />
        </div>
      )}

      {phase === "listening" && !textMode && (
        <p className="text-center text-sm text-slate-400">
          Take your time — click &quot;Finished answer&quot; when you&apos;re done, or pause and we&apos;ll
          move on automatically.
        </p>
      )}

      {phase === "listening" && textMode && (
        <div className="mx-auto w-full max-w-xl">
          <textarea
            autoFocus
            value={typedAnswer}
            onChange={(e) => setTypedAnswer(e.target.value)}
            rows={6}
            placeholder="Type your answer here..."
            className="w-full rounded-md border border-panel-border bg-panel-surface px-3 py-2 text-sm outline-none focus:border-brand-500"
          />
        </div>
      )}

      {!forcedTextMode && (
        <div className="mx-auto flex w-full max-w-xl justify-end">
          <button
            onClick={() => {
              const switchingToText = !textMode;
              if (phase === "listening") {
                if (switchingToText) stopListening();
                else {
                  setLiveTranscript("");
                  try {
                    recognitionRef.current?.start();
                  } catch {
                    // already started — ignore
                  }
                }
              }
              setTextMode(switchingToText);
            }}
            disabled={phase !== "listening"}
            className="text-xs text-slate-500 hover:text-slate-300 disabled:opacity-40"
          >
            {textMode ? "Switch to speaking" : "Type my answer instead"}
          </button>
        </div>
      )}

      <Controls
        questionNumber={Math.min(questionIndex + 1, session.questions.length)}
        totalQuestions={session.questions.length}
        micOn={micOn}
        onToggleMic={toggleMic}
        onFinishAnswer={finishAnswer}
        onEndInterview={endInterview}
        captionsOn={captionsVisible}
        onToggleCaptions={() => setCaptionsVisible((v) => !v)}
        canFinishAnswer={phase === "listening" && (textMode ? typedAnswer.trim().length > 0 : true)}
      />
    </div>
  );
}
