"use client";

export function Controls({
  questionNumber,
  totalQuestions,
  micOn,
  onToggleMic,
  onFinishAnswer,
  onEndInterview,
  captionsOn,
  onToggleCaptions,
  canFinishAnswer,
}: {
  questionNumber: number;
  totalQuestions: number;
  micOn: boolean;
  onToggleMic: () => void;
  onFinishAnswer: () => void;
  onEndInterview: () => void;
  captionsOn: boolean;
  onToggleCaptions: () => void;
  canFinishAnswer: boolean;
}) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-panel-border bg-panel-surface px-5 py-3">
      <span className="text-sm text-slate-400">
        Question {questionNumber} of {totalQuestions}
      </span>

      <div className="flex flex-wrap items-center gap-3">
        <button
          onClick={onToggleMic}
          className={`rounded-md border px-3 py-1.5 text-sm ${
            micOn ? "border-panel-border hover:border-brand-500" : "border-red-500 text-red-400"
          }`}
        >
          {micOn ? "Mute" : "Unmute"}
        </button>
        <button
          onClick={onToggleCaptions}
          className="rounded-md border border-panel-border px-3 py-1.5 text-sm hover:border-brand-500"
        >
          {captionsOn ? "Hide captions" : "Show captions"}
        </button>
        <button
          onClick={onFinishAnswer}
          disabled={!canFinishAnswer}
          className="rounded-md bg-brand-500 px-4 py-1.5 text-sm font-medium text-white hover:bg-brand-600 disabled:opacity-40"
        >
          Finished answer
        </button>
        <button onClick={onEndInterview} className="rounded-md border border-red-500/60 px-3 py-1.5 text-sm text-red-400 hover:bg-red-500/10">
          End interview
        </button>
      </div>
    </div>
  );
}
