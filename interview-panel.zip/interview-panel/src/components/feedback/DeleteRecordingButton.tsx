"use client";

import { useState } from "react";

export function DeleteRecordingButton({ sessionId }: { sessionId: string }) {
  const [status, setStatus] = useState<"idle" | "deleting" | "done">("idle");

  async function handleDelete() {
    if (!confirm("Delete the audio recording for this interview? Your transcript, coaching, and playbook stay.")) {
      return;
    }
    setStatus("deleting");
    await fetch(`/api/interview-sessions/${sessionId}/recording`, { method: "DELETE" });
    setStatus("done");
  }

  if (status === "done") {
    return <span className="text-xs text-slate-500">Recording deleted</span>;
  }

  return (
    <button
      onClick={handleDelete}
      disabled={status === "deleting"}
      className="rounded-md border border-panel-border px-3 py-1.5 text-xs text-slate-400 hover:border-red-500/60 hover:text-red-400 disabled:opacity-50"
    >
      {status === "deleting" ? "Deleting..." : "Delete recording"}
    </button>
  );
}
