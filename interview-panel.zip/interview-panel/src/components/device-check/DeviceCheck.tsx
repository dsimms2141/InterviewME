"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

type PermissionState = "idle" | "requesting" | "granted" | "denied" | "audio-only" | "text-only";

export function DeviceCheck({ sessionId }: { sessionId: string }) {
  const router = useRouter();
  const videoRef = useRef<HTMLVideoElement>(null);
  const [permission, setPermission] = useState<PermissionState>("idle");
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [microphones, setMicrophones] = useState<MediaDeviceInfo[]>([]);
  const [selectedCamera, setSelectedCamera] = useState<string>("");
  const [selectedMic, setSelectedMic] = useState<string>("");
  const [networkOk, setNetworkOk] = useState<boolean | null>(null);
  const [entering, setEntering] = useState(false);

  const canEnter = permission === "granted" || permission === "audio-only" || permission === "text-only";

  useEffect(() => {
    setNetworkOk(navigator.onLine);
    const goOnline = () => setNetworkOk(true);
    const goOffline = () => setNetworkOk(false);
    window.addEventListener("online", goOnline);
    window.addEventListener("offline", goOffline);
    return () => {
      window.removeEventListener("online", goOnline);
      window.removeEventListener("offline", goOffline);
    };
  }, []);

  async function requestPermissions() {
    setPermission("requesting");
    try {
      const media = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      setStream(media);
      setPermission("granted");
      if (videoRef.current) videoRef.current.srcObject = media;

      const devices = await navigator.mediaDevices.enumerateDevices();
      setCameras(devices.filter((d) => d.kind === "videoinput"));
      setMicrophones(devices.filter((d) => d.kind === "audioinput"));
    } catch {
      setPermission("denied");
    }
  }

  async function continueWithAudioOnly() {
    setPermission("requesting");
    try {
      const media = await navigator.mediaDevices.getUserMedia({ video: false, audio: true });
      setStream(media);
      setPermission("audio-only");
      const devices = await navigator.mediaDevices.enumerateDevices();
      setMicrophones(devices.filter((d) => d.kind === "audioinput"));
    } catch {
      setPermission("denied");
    }
  }

  function continueTextOnly() {
    setPermission("text-only");
  }

  async function handleEnter() {
    setEntering(true);
    const query = permission === "text-only" ? "?mode=text" : "";
    router.push(`/interview/${sessionId}/room${query}`);
  }

  return (
    <div className="grid gap-8 lg:grid-cols-[1.2fr_1fr]">
      <div className="overflow-hidden rounded-xl border border-panel-border bg-black">
        {permission === "granted" ? (
          <video ref={videoRef} autoPlay muted playsInline className="aspect-video w-full object-cover" />
        ) : permission === "audio-only" || permission === "text-only" ? (
          <div className="flex aspect-video w-full flex-col items-center justify-center gap-2 bg-panel-surface p-8 text-center">
            <p className="text-slate-300">
              {permission === "audio-only"
                ? "Continuing without your camera — the panel will still hear you."
                : "Continuing in text mode — no camera or microphone needed."}
            </p>
          </div>
        ) : (
          <div className="flex aspect-video w-full flex-col items-center justify-center gap-4 bg-panel-surface p-8 text-center">
            <p className="text-slate-300">
              We need access to your camera and microphone so the panel can see and hear you, just like a
              real video interview.
            </p>
            <button
              onClick={requestPermissions}
              className="rounded-md bg-brand-500 px-5 py-2.5 font-medium text-white hover:bg-brand-600"
            >
              {permission === "requesting" ? "Requesting access..." : "Enable camera & microphone"}
            </button>
            {permission === "denied" && (
              <p className="max-w-sm text-sm text-red-400">
                Access was denied. Check your browser&apos;s site settings and try again, or use one of the
                accessibility options below.
              </p>
            )}
            <div className="mt-2 flex flex-col gap-1 text-xs text-slate-400">
              <button onClick={continueWithAudioOnly} className="underline hover:text-slate-200">
                Continue without a camera (audio only)
              </button>
              <button onClick={continueTextOnly} className="underline hover:text-slate-200">
                Skip camera and microphone — I&apos;ll type my answers
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="flex flex-col gap-5">
        <CheckRow
          label="Camera"
          status={
            permission === "granted"
              ? "ready"
              : permission === "audio-only" || permission === "text-only"
                ? "skipped"
                : "unavailable"
          }
        />
        <CheckRow
          label="Microphone"
          status={
            permission === "granted" || permission === "audio-only"
              ? "ready"
              : permission === "text-only"
                ? "skipped"
                : "unavailable"
          }
        />
        <CheckRow label="Network connection" status={networkOk === null ? "checking" : networkOk ? "ready" : "unavailable"} />

        {permission === "granted" && (
          <>
            <label className="flex flex-col gap-1 text-sm">
              Camera
              <select
                value={selectedCamera}
                onChange={(e) => setSelectedCamera(e.target.value)}
                className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 text-sm"
              >
                {cameras.map((c) => (
                  <option key={c.deviceId} value={c.deviceId}>
                    {c.label || "Camera"}
                  </option>
                ))}
              </select>
            </label>
            <label className="flex flex-col gap-1 text-sm">
              Microphone
              <select
                value={selectedMic}
                onChange={(e) => setSelectedMic(e.target.value)}
                className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 text-sm"
              >
                {microphones.map((m) => (
                  <option key={m.deviceId} value={m.deviceId}>
                    {m.label || "Microphone"}
                  </option>
                ))}
              </select>
            </label>
          </>
        )}

        <p className="rounded-md border border-panel-border bg-panel-surface p-3 text-xs text-slate-400">
          Recording and transcription only begin once you enter the interview room, and only for this
          practice session. You can manage what&apos;s saved in Settings at any time.
        </p>

        <button
          onClick={handleEnter}
          disabled={!canEnter || entering}
          className="rounded-lg bg-brand-500 py-3 font-medium text-white transition hover:bg-brand-600 disabled:cursor-not-allowed disabled:opacity-40"
        >
          {entering ? "Entering..." : "Enter interview room"}
        </button>
      </div>
    </div>
  );
}

type CheckStatus = "checking" | "ready" | "unavailable" | "skipped";

function CheckRow({ label, status }: { label: string; status: CheckStatus }) {
  const color =
    status === "ready"
      ? "bg-emerald-500"
      : status === "skipped"
        ? "bg-slate-500"
        : status === "checking"
          ? "bg-slate-500"
          : "bg-red-500";
  const text =
    status === "ready"
      ? "Ready"
      : status === "skipped"
        ? "Not used"
        : status === "checking"
          ? "Checking..."
          : "Unavailable";
  return (
    <div className="flex items-center justify-between rounded-md border border-panel-border bg-panel-surface px-4 py-3 text-sm">
      <span>{label}</span>
      <span className="flex items-center gap-2 text-slate-400">
        <span className={`h-2 w-2 rounded-full ${color}`} />
        {text}
      </span>
    </div>
  );
}
