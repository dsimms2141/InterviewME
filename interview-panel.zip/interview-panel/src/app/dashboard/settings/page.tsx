"use client";

import { useEffect, useState } from "react";

interface Settings {
  saveVideoRecordings: boolean;
  saveAudioRecordings: boolean;
  storeTranscripts: boolean;
  captionsEnabled: boolean;
  preferredCameraId: string | null;
  preferredMicrophoneId: string | null;
  audioVolume: number;
  highContrast: boolean;
}

export default function SettingsPage() {
  const [settings, setSettings] = useState<Settings | null>(null);
  const [saving, setSaving] = useState(false);
  const [savedAt, setSavedAt] = useState<number | null>(null);
  const [cameras, setCameras] = useState<MediaDeviceInfo[]>([]);
  const [microphones, setMicrophones] = useState<MediaDeviceInfo[]>([]);

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((data) => setSettings(data.settings));

    navigator.mediaDevices?.enumerateDevices().then((devices) => {
      setCameras(devices.filter((d) => d.kind === "videoinput"));
      setMicrophones(devices.filter((d) => d.kind === "audioinput"));
    });
  }, []);

  async function update(patch: Partial<Settings>) {
    if (!settings) return;
    const next = { ...settings, ...patch };
    setSettings(next);
    setSaving(true);
    await fetch("/api/settings", {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(patch),
    });
    setSaving(false);
    setSavedAt(Date.now());
  }

  if (!settings) {
    return <main className="mx-auto max-w-3xl px-6 py-10 text-slate-400">Loading settings...</main>;
  }

  return (
    <main className="mx-auto max-w-3xl px-6 py-10">
      <h1 className="mb-1 text-2xl font-semibold">Settings</h1>
      <p className="mb-8 text-sm text-slate-400">
        {saving ? "Saving..." : savedAt ? "All changes saved" : "Manage your devices and privacy preferences."}
      </p>

      <SectionCard title="Devices">
        <label className="flex flex-col gap-1 text-sm">
          Preferred camera
          <select
            value={settings.preferredCameraId ?? ""}
            onChange={(e) => update({ preferredCameraId: e.target.value || null })}
            className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 text-sm"
          >
            <option value="">System default</option>
            {cameras.map((c) => (
              <option key={c.deviceId} value={c.deviceId}>
                {c.label || "Camera"}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Preferred microphone
          <select
            value={settings.preferredMicrophoneId ?? ""}
            onChange={(e) => update({ preferredMicrophoneId: e.target.value || null })}
            className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 text-sm"
          >
            <option value="">System default</option>
            {microphones.map((m) => (
              <option key={m.deviceId} value={m.deviceId}>
                {m.label || "Microphone"}
              </option>
            ))}
          </select>
        </label>
        <label className="flex flex-col gap-1 text-sm">
          Audio volume ({settings.audioVolume}%)
          <input
            type="range"
            min={0}
            max={100}
            value={settings.audioVolume}
            onChange={(e) => update({ audioVolume: Number(e.target.value) })}
          />
        </label>
      </SectionCard>

      <SectionCard title="Privacy">
        <ToggleRow
          label="Save video recordings"
          description="Off by default. Video is used for immersion and optional presentation feedback only — never for scoring."
          checked={settings.saveVideoRecordings}
          onChange={(v) => update({ saveVideoRecordings: v })}
        />
        <ToggleRow
          label="Save audio recordings"
          description="Needed to re-run transcription later. Turn off to discard audio right after it's transcribed."
          checked={settings.saveAudioRecordings}
          onChange={(v) => update({ saveAudioRecordings: v })}
        />
        <ToggleRow
          label="Store transcripts"
          description="Keeps your answer transcripts so you can review past interviews and playbooks."
          checked={settings.storeTranscripts}
          onChange={(v) => update({ storeTranscripts: v })}
        />
      </SectionCard>

      <SectionCard title="Accessibility">
        <ToggleRow
          label="Captions by default"
          description="Show live captions automatically when you enter an interview room."
          checked={settings.captionsEnabled}
          onChange={(v) => update({ captionsEnabled: v })}
        />
        <ToggleRow
          label="High contrast"
          description="Increases contrast across the app."
          checked={settings.highContrast}
          onChange={(v) => update({ highContrast: v })}
        />
      </SectionCard>
    </main>
  );
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-6 rounded-xl border border-panel-border bg-panel-surface p-5">
      <h2 className="mb-4 text-sm font-semibold uppercase tracking-wide text-slate-400">{title}</h2>
      <div className="flex flex-col gap-4">{children}</div>
    </section>
  );
}

function ToggleRow({
  label,
  description,
  checked,
  onChange,
}: {
  label: string;
  description: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-start justify-between gap-4">
      <div>
        <p className="text-sm font-medium">{label}</p>
        <p className="mt-0.5 text-xs text-slate-400">{description}</p>
      </div>
      <button
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={`relative h-6 w-11 shrink-0 rounded-full transition ${checked ? "bg-brand-500" : "bg-slate-600"}`}
      >
        <span
          className={`absolute top-0.5 h-5 w-5 rounded-full bg-white transition ${checked ? "left-5" : "left-0.5"}`}
        />
      </button>
    </div>
  );
}
