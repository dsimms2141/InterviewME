"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface JobProfile {
  id: string;
  title: string;
  company: string | null;
  industry: string | null;
  updatedAt: string;
}

type Step = "idle" | "panel" | "questions" | "error";

export default function SavedJobsPage() {
  const router = useRouter();
  const [jobs, setJobs] = useState<JobProfile[] | null>(null);
  const [practicingJobId, setPracticingJobId] = useState<string | null>(null);
  const [step, setStep] = useState<Step>("idle");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/job-profiles")
      .then((r) => r.json())
      .then((data) => setJobs(data.jobProfiles));
  }, []);

  async function handleDelete(id: string) {
    if (!confirm("Delete this saved job? This won't delete past interviews you've already completed for it.")) return;
    await fetch(`/api/job-profiles/${id}`, { method: "DELETE" });
    setJobs((prev) => prev?.filter((j) => j.id !== id) ?? null);
  }

  async function handlePractice(jobProfileId: string, mode: "PRACTICE" | "REALISTIC" | "PRESSURE") {
    setPracticingJobId(jobProfileId);
    setError(null);
    try {
      const sessionRes = await postJson("/api/interview-sessions", { jobProfileId, mode });
      const interviewSessionId = sessionRes.interviewSession.id as string;

      setStep("panel");
      await postJson(`/api/interview-sessions/${interviewSessionId}/panel`, {});

      setStep("questions");
      await postJson(`/api/interview-sessions/${interviewSessionId}/questions`, {});

      router.push(`/interview/${interviewSessionId}/device-check`);
    } catch (err) {
      setError((err as Error).message);
      setStep("error");
      setPracticingJobId(null);
    }
  }

  if (practicingJobId) {
    return (
      <main className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center px-6 text-center">
        <div className="mb-6 h-10 w-10 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
        <p className="text-lg font-medium">
          {step === "panel" && "Assembling your interview panel..."}
          {step === "questions" && "Writing your interview questions..."}
          {step === "error" && "Something went wrong"}
        </p>
        {step === "error" && <p className="mt-2 text-sm text-red-400">{error}</p>}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl px-6 py-10">
      <h1 className="mb-1 text-2xl font-semibold">Saved jobs</h1>
      <p className="mb-8 text-sm text-slate-400">Practice repeatedly for the same position.</p>

      {jobs === null ? (
        <p className="text-slate-400">Loading...</p>
      ) : jobs.length === 0 ? (
        <p className="rounded-lg border border-dashed border-panel-border p-6 text-sm text-slate-400">
          No saved jobs yet — start a new interview to save one automatically.
        </p>
      ) : (
        <ul className="flex flex-col gap-3">
          {jobs.map((job) => (
            <li key={job.id} className="rounded-lg border border-panel-border bg-panel-surface p-4">
              <div className="flex items-start justify-between gap-4">
                <div>
                  <p className="font-medium">{job.title}</p>
                  <p className="text-sm text-slate-400">
                    {job.company || job.industry || "No additional detail"}
                  </p>
                </div>
                <div className="flex shrink-0 items-center gap-2">
                  <JobPracticeMenu onSelect={(mode) => handlePractice(job.id, mode)} />
                  <button
                    onClick={() => handleDelete(job.id)}
                    className="rounded-md border border-red-500/40 px-3 py-1.5 text-xs text-red-400 hover:bg-red-500/10"
                  >
                    Delete
                  </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
      )}
    </main>
  );
}

function JobPracticeMenu({ onSelect }: { onSelect: (mode: "PRACTICE" | "REALISTIC" | "PRESSURE") => void }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="rounded-md bg-brand-500 px-3 py-1.5 text-xs font-medium text-white hover:bg-brand-600"
      >
        Practice again
      </button>
      {open && (
        <div className="absolute right-0 z-10 mt-1 w-40 rounded-md border border-panel-border bg-panel-surface p-1 shadow-lg">
          {(["PRACTICE", "REALISTIC", "PRESSURE"] as const).map((mode) => (
            <button
              key={mode}
              onClick={() => onSelect(mode)}
              className="block w-full rounded px-2 py-1.5 text-left text-xs hover:bg-panel-bg"
            >
              {mode.charAt(0) + mode.slice(1).toLowerCase()}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

async function postJson(url: string, body: unknown) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? `Request to ${url} failed`);
  return data;
}
