import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { DeleteSessionButton } from "@/components/dashboard/DeleteSessionButton";
import { computePerformanceTrends } from "@/lib/analysis/performanceTrends";

export default async function DashboardPage() {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) redirect("/login");

  const [recentSessions, jobProfiles, practiceGoals, responses] = await Promise.all([
    db.interviewSession.findMany({
      where: { userId },
      include: { jobProfile: true, evaluation: true },
      orderBy: { createdAt: "desc" },
      take: 5,
    }),
    db.jobProfile.findMany({ where: { userId }, orderBy: { updatedAt: "desc" }, take: 6 }),
    db.practiceGoal.findMany({ where: { userId, status: "ACTIVE" } }),
    db.response.findMany({
      where: { interviewSession: { userId }, isFollowUp: false },
      orderBy: { createdAt: "asc" },
      select: { durationSeconds: true, fillerWordCount: true, starDetected: true, createdAt: true },
    }),
  ]);

  const completed = recentSessions.filter((s) => s.completionStatus === "COMPLETED");
  const inProgress = recentSessions.find(
    (s) => s.completionStatus === "IN_PROGRESS" || s.completionStatus === "NOT_STARTED"
  );
  const trends = computePerformanceTrends(responses);

  return (
    <main className="mx-auto max-w-6xl px-6 py-10">
      <header className="mb-10 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">Welcome back{session?.user?.name ? `, ${session.user.name}` : ""}</p>
          <h1 className="text-3xl font-semibold">Your interview prep dashboard</h1>
        </div>
        <Link
          href="/interview/new"
          className="rounded-lg bg-brand-500 px-5 py-2.5 font-medium text-white transition hover:bg-brand-600"
        >
          Start New Interview
        </Link>
      </header>

      <section className="mb-10 grid gap-4 sm:grid-cols-3">
        <StatCard label="Interviews completed" value={completed.length} />
        <StatCard label="Saved jobs" value={jobProfiles.length} />
        <StatCard label="Active practice goals" value={practiceGoals.length} />
      </section>

      {trends.interviewsAnswered > 0 && (
        <section className="mb-10">
          <h2 className="mb-4 text-lg font-semibold">Performance trends</h2>
          <div className="grid gap-4 sm:grid-cols-3">
            <TrendCard
              label="Average answer length"
              value={trends.averageAnswerLengthSeconds ? `${trends.averageAnswerLengthSeconds}s` : "—"}
            />
            <TrendCard label="Filler word trend" value={trends.fillerWordTrend} />
            <TrendCard label="STAR structure trend" value={trends.starStructureTrend} />
          </div>
        </section>
      )}

      {inProgress && (
        <section className="mb-10 rounded-xl border border-panel-border bg-panel-surface p-5">
          <p className="text-sm text-slate-400">Continue practice</p>
          <p className="mt-1 text-lg font-medium">{inProgress.jobProfile.title}</p>
          <Link
            href={`/interview/${inProgress.id}/device-check`}
            className="mt-3 inline-block rounded-md bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600"
          >
            Resume
          </Link>
        </section>
      )}

      <section className="grid gap-8 lg:grid-cols-2">
        <div>
          <h2 className="mb-4 text-lg font-semibold">Interview history</h2>
          {recentSessions.length === 0 ? (
            <EmptyState text="No interviews yet — start your first mock interview above." />
          ) : (
            <ul className="flex flex-col gap-3">
              {recentSessions.map((s) => (
                <li key={s.id} className="rounded-lg border border-panel-border bg-panel-surface p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">{s.jobProfile.title}</p>
                      <p className="text-sm text-slate-400">
                        {s.mode.charAt(0) + s.mode.slice(1).toLowerCase()} · {s.completionStatus.replace("_", " ").toLowerCase()}
                      </p>
                    </div>
                    <div className="flex items-center gap-3">
                      {s.completionStatus === "COMPLETED" ? (
                        <Link href={`/interview/${s.id}/feedback`} className="text-sm text-brand-300 hover:underline">
                          View feedback →
                        </Link>
                      ) : (
                        <Link href={`/interview/${s.id}/device-check`} className="text-sm text-brand-300 hover:underline">
                          Resume →
                        </Link>
                      )}
                      <DeleteSessionButton sessionId={s.id} />
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-lg font-semibold">Saved jobs</h2>
            <Link href="/dashboard/jobs" className="text-sm text-brand-300 hover:underline">
              View all →
            </Link>
          </div>
          {jobProfiles.length === 0 ? (
            <EmptyState text="Jobs you prepare for will be saved here for repeat practice." />
          ) : (
            <ul className="flex flex-col gap-3">
              {jobProfiles.map((j) => (
                <li key={j.id} className="rounded-lg border border-panel-border bg-panel-surface p-4">
                  <p className="font-medium">{j.title}</p>
                  <p className="text-sm text-slate-400">{j.company || "Company not specified"}</p>
                </li>
              ))}
            </ul>
          )}
        </div>
      </section>
    </main>
  );
}

function StatCard({ label, value }: { label: string; value: number }) {
  return (
    <div className="rounded-xl border border-panel-border bg-panel-surface p-5">
      <p className="text-sm text-slate-400">{label}</p>
      <p className="mt-1 text-3xl font-semibold">{value}</p>
    </div>
  );
}

function TrendCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl border border-panel-border bg-panel-surface p-5">
      <p className="text-sm text-slate-400">{label}</p>
      <p className="mt-1 text-lg font-medium capitalize">{value}</p>
    </div>
  );
}

function EmptyState({ text }: { text: string }) {
  return <p className="rounded-lg border border-dashed border-panel-border p-6 text-sm text-slate-400">{text}</p>;
}
