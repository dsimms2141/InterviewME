import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect } from "next/navigation";
import { authOptions } from "@/lib/auth";

export default async function HomePage() {
  const session = await getServerSession(authOptions);
  if (session) redirect("/dashboard");

  return (
    <main className="mx-auto flex min-h-screen max-w-5xl flex-col items-center justify-center gap-8 px-6 text-center">
      <span className="rounded-full border border-panel-border bg-panel-surface px-4 py-1 text-sm text-brand-300">
        Executive interview coaching, reimagined
      </span>
      <h1 className="max-w-3xl text-4xl font-semibold leading-tight sm:text-5xl">
        Practice in front of a live, animated three-person interview panel
      </h1>
      <p className="max-w-2xl text-lg text-slate-300">
        Tell us the job you&apos;re preparing for. We&apos;ll assemble a realistic panel of AI
        interviewers, run a full mock interview over your webcam, and hand you a personalized
        coaching playbook afterward.
      </p>
      <div className="flex gap-4">
        <Link
          href="/register"
          className="rounded-lg bg-brand-500 px-6 py-3 font-medium text-white transition hover:bg-brand-600"
        >
          Get started
        </Link>
        <Link
          href="/login"
          className="rounded-lg border border-panel-border px-6 py-3 font-medium text-slate-200 transition hover:border-brand-500"
        >
          Sign in
        </Link>
      </div>
    </main>
  );
}
