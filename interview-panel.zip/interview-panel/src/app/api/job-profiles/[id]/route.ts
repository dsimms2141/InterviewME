import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const jobProfile = await db.jobProfile.findFirst({
      where: { id: params.id, userId },
      include: { interviewSessions: { include: { evaluation: true }, orderBy: { createdAt: "desc" } } },
    });
    if (!jobProfile) return NextResponse.json({ error: "Job profile not found" }, { status: 404 });
    return NextResponse.json({ jobProfile });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const jobProfile = await db.jobProfile.findFirst({ where: { id: params.id, userId } });
    if (!jobProfile) return NextResponse.json({ error: "Job profile not found" }, { status: 404 });

    await db.jobProfile.delete({ where: { id: jobProfile.id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
