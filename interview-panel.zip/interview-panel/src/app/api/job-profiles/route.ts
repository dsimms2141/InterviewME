import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

const createSchema = z.object({
  title: z.string().min(1),
  company: z.string().optional(),
  interviewDate: z.string().datetime().optional(),
  rawDescription: z.string().optional(),
  sourceType: z.enum(["TITLE_ONLY", "PASTED_DESCRIPTION", "UPLOADED_DOCUMENT"]).default("TITLE_ONLY"),
});

export async function GET() {
  try {
    const userId = await requireUserId();
    const profiles = await db.jobProfile.findMany({
      where: { userId },
      orderBy: { updatedAt: "desc" },
    });
    return NextResponse.json({ jobProfiles: profiles });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}

export async function POST(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = createSchema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const profile = await db.jobProfile.create({
      data: {
        userId,
        title: parsed.data.title,
        company: parsed.data.company,
        interviewDate: parsed.data.interviewDate ? new Date(parsed.data.interviewDate) : undefined,
        rawDescription: parsed.data.rawDescription,
        sourceType: parsed.data.sourceType,
      },
    });

    return NextResponse.json({ jobProfile: profile }, { status: 201 });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
