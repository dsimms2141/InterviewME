import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { analyzeJob } from "@/lib/llm/jobAnalysis";

const schema = z.object({ jobProfileId: z.string().min(1) });

// Runs the AI job-analysis step (section 4): extracts the INTERVIEW
// COMPETENCY PROFILE from the job title/description and persists it onto
// the JobProfile row, so panel + question generation can read it back
// without re-calling the LLM.
export async function POST(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const profile = await db.jobProfile.findFirst({
      where: { id: parsed.data.jobProfileId, userId },
    });
    if (!profile) return NextResponse.json({ error: "Job profile not found" }, { status: 404 });

    const competencyProfile = await analyzeJob({
      title: profile.title,
      description: profile.rawDescription ?? undefined,
    });

    const updated = await db.jobProfile.update({
      where: { id: profile.id },
      data: {
        industry: competencyProfile.industry,
        seniority: competencyProfile.seniority,
        responsibilities: competencyProfile.responsibilities,
        requiredSkills: competencyProfile.requiredSkills,
        leadershipExpectations: competencyProfile.leadershipExpectations,
        technicalCompetencies: competencyProfile.technicalCompetencies,
        behavioralCompetencies: competencyProfile.behavioralCompetencies,
        customerResponsibilities: competencyProfile.customerResponsibilities,
        problemSolvingExpectations: competencyProfile.problemSolvingExpectations,
        communicationRequirements: competencyProfile.communicationRequirements,
        managementExpectations: competencyProfile.managementExpectations,
        relevantTerminology: competencyProfile.relevantTerminology,
      },
    });

    return NextResponse.json({ jobProfile: updated });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
