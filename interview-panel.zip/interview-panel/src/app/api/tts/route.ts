import { NextResponse } from "next/server";
import { z } from "zod";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { getTtsProvider } from "@/lib/speech/tts";
import { recordUsage } from "@/lib/costs/usageTracker";

const schema = z.object({
  text: z.string().min(1),
  voiceId: z.string().min(1),
  interviewSessionId: z.string().optional(),
});

// Synthesizes one line of interviewer dialogue. Called by the interview
// room right before handing the audio to the avatar provider's speak()
// (audio-passthrough mode) — kept as its own endpoint so a future
// server-driven orchestration loop (e.g. a WebSocket session) can call it
// without going through the browser.
export async function POST(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const tts = getTtsProvider();
    const result = await tts.synthesize({ text: parsed.data.text, voiceId: parsed.data.voiceId });

    await recordUsage({
      interviewSessionId: parsed.data.interviewSessionId,
      userId,
      kind: "TTS_CHARACTERS",
      quantity: parsed.data.text.length,
      unit: "tts_characters",
      provider: tts.name,
    });

    return NextResponse.json(result);
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
