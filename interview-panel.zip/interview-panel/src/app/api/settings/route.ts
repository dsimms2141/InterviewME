import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

const schema = z.object({
  saveVideoRecordings: z.boolean().optional(),
  saveAudioRecordings: z.boolean().optional(),
  storeTranscripts: z.boolean().optional(),
  captionsEnabled: z.boolean().optional(),
  preferredCameraId: z.string().nullable().optional(),
  preferredMicrophoneId: z.string().nullable().optional(),
  audioVolume: z.number().min(0).max(100).optional(),
  highContrast: z.boolean().optional(),
});

// Section 3 / 24 / 25: manage camera+mic device preferences and privacy
// preferences (recording/transcript retention, captions, high contrast)
// from one settings screen. UserSettings is created alongside the user at
// registration, so this is always an update, never a create.
export async function GET() {
  try {
    const userId = await requireUserId();
    const settings = await db.userSettings.upsert({
      where: { userId },
      update: {},
      create: { userId },
    });
    return NextResponse.json({ settings });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}

export async function PATCH(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const settings = await db.userSettings.upsert({
      where: { userId },
      update: parsed.data,
      create: { userId, ...parsed.data },
    });

    return NextResponse.json({ settings });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
