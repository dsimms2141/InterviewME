import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { deleteResponseAudio } from "@/lib/storage";

// Section 3: "Delete recordings" as a distinct action from deleting the
// whole interview — the transcript, coaching, and playbook are kept, only
// the underlying audio (and any stored video) is removed.
export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({ where: { id: params.id, userId } });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    const responsesWithAudio = await db.response.findMany({
      where: { interviewSessionId: session.id, audioUrl: { not: null } },
      select: { id: true, audioUrl: true },
    });

    await Promise.all(
      responsesWithAudio.map((r) => (r.audioUrl ? deleteResponseAudio(r.audioUrl) : Promise.resolve()))
    );

    await db.$transaction([
      db.response.updateMany({
        where: { interviewSessionId: session.id },
        data: { audioUrl: null },
      }),
      db.interviewSession.update({
        where: { id: session.id },
        data: { videoRetained: false, audioRetained: false },
      }),
    ]);

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
