import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { InterviewOrchestrator } from "@/lib/orchestrator/InterviewOrchestrator";
import { getSttProvider } from "@/lib/speech/stt";
import { recordUsage } from "@/lib/costs/usageTracker";
import { uploadResponseAudio } from "@/lib/storage";

const schema = z.object({
  questionId: z.string().min(1),
  isFollowUp: z.boolean().default(false),
  followUpText: z.string().optional(), // text of the follow-up question, if any
  // The client always sends the browser's live transcript as a fallback;
  // audioBase64 is optional and only present when audio recording/upload is
  // enabled in the candidate's privacy settings (section 24).
  clientTranscript: z.string().min(1),
  audioBase64: z.string().optional(),
  audioMimeType: z.string().optional(),
  durationSeconds: z.number().int().positive(),
});

// Records one candidate answer, transcribes it server-side when audio was
// captured, runs it through the orchestrator (observable-signal analysis +
// follow-up decision), and returns either a follow-up question to ask next
// or a signal to advance to the next primary question.
export async function POST(req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({
      where: { id: params.id, userId },
      include: { jobProfile: true },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const question = await db.question.findFirst({
      where: { id: parsed.data.questionId, interviewSessionId: session.id },
    });
    if (!question) return NextResponse.json({ error: "Question not found on this session" }, { status: 404 });

    let transcript = parsed.data.clientTranscript;
    if (parsed.data.audioBase64 && parsed.data.audioMimeType) {
      const stt = getSttProvider();
      const result = await stt.transcribe({
        audioBase64: parsed.data.audioBase64,
        mimeType: parsed.data.audioMimeType,
      });
      if (result.transcript.trim().length > 0) transcript = result.transcript;

      await recordUsage({
        interviewSessionId: session.id,
        userId,
        kind: "STT_MINUTES",
        quantity: parsed.data.durationSeconds / 60,
        unit: "stt_minutes",
        provider: stt.name,
      });
    }

    const response = await db.response.create({
      data: {
        questionId: question.id,
        interviewSessionId: session.id,
        isFollowUp: parsed.data.isFollowUp,
        transcript,
        durationSeconds: parsed.data.durationSeconds,
        audioUrl: null,
        startedAt: new Date(Date.now() - parsed.data.durationSeconds * 1000),
        endedAt: new Date(),
      },
    });

    // Only upload audio when the candidate has opted into retention
    // (defaults to on for audio, off for video — section 24) and audio was
    // actually captured this turn.
    if (parsed.data.audioBase64 && parsed.data.audioMimeType) {
      const settings = await db.userSettings.findUnique({ where: { userId } });
      if (settings?.saveAudioRecordings !== false) {
        const stored = await uploadResponseAudio({
          interviewSessionId: session.id,
          responseId: response.id,
          audioBase64: parsed.data.audioBase64,
          mimeType: parsed.data.audioMimeType,
        });
        if (stored) {
          await db.response.update({ where: { id: response.id }, data: { audioUrl: stored.url } });
          await db.interviewSession.update({ where: { id: session.id }, data: { audioRetained: true } });
        }
      }
    }

    const orchestrator = new InterviewOrchestrator(session.id);
    const { followUp } = await orchestrator.processAnswer({
      responseId: response.id,
      questionId: question.id,
      questionText: parsed.data.isFollowUp ? parsed.data.followUpText ?? question.text : question.text,
      testingFor: question.testingFor ?? "",
      transcript,
      durationSeconds: parsed.data.durationSeconds,
      mode: session.mode,
    });

    return NextResponse.json({ responseId: response.id, transcript, followUp });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
