import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { generatePanel } from "@/lib/llm/panelGeneration";
import { toCompetencyProfile } from "@/lib/jobProfileMapper";
import { assertTransition } from "@/lib/orchestrator/stateMachine";

// Generates a fresh, randomized 3-person panel (section 6) and persists the
// interviewers + seat assignments. Always generates new Interviewer rows
// rather than reusing a pool, so panels don't repeat identically across
// sessions per the "do not repeatedly generate identical panels" rule.
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({
      where: { id: params.id, userId },
      include: { jobProfile: true },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    assertTransition(session.state, "PANEL_GENERATION");
    await db.interviewSession.update({ where: { id: session.id }, data: { state: "PANEL_GENERATION" } });

    const generated = await generatePanel({
      jobTitle: session.jobProfile.title,
      competencyProfile: toCompetencyProfile(session.jobProfile),
    });

    const panel = await db.$transaction(async (tx) => {
      const memberships = [];
      for (const gen of generated.interviewers) {
        const interviewer = await tx.interviewer.create({
          data: {
            firstName: gen.firstName,
            lastName: gen.lastName,
            title: gen.title,
            department: gen.department,
            primaryCompetency: gen.primaryCompetency,
            interviewStyle: gen.interviewStyle,
            personality: gen.personality,
            appearanceSeed: gen.appearanceSeed,
            // voiceProviderId is resolved lazily on first TTS call and
            // cached here — see lib/speech voice-mapping note below.
          },
        });

        const membership = await tx.panelMembership.create({
          data: {
            interviewSessionId: session.id,
            interviewerId: interviewer.id,
            seatOrder: gen.seatOrder,
          },
          include: { interviewer: true },
        });
        memberships.push(membership);
      }

      await tx.interviewSession.update({
        where: { id: session.id },
        data: { state: "DEVICE_CHECK" },
      });

      return memberships;
    });

    return NextResponse.json({ panel });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
