import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({
      where: { id: params.id, userId },
      include: {
        jobProfile: true,
        panel: { include: { interviewer: true }, orderBy: { seatOrder: "asc" } },
        questions: { orderBy: { order: "asc" } },
        responses: { orderBy: { createdAt: "asc" } },
        evaluation: { include: { items: true } },
        playbook: true,
      },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });
    return NextResponse.json({ interviewSession: session });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}

export async function DELETE(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({ where: { id: params.id, userId } });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    await db.interviewSession.delete({ where: { id: session.id } });
    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
