import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({ where: { id: params.id, userId } });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    const evaluation = await db.evaluation.findUnique({
      where: { interviewSessionId: session.id },
      include: {
        items: {
          include: { response: { include: { question: true } } },
        },
      },
    });
    if (!evaluation) return NextResponse.json({ error: "Evaluation not ready yet" }, { status: 404 });

    return NextResponse.json({ evaluation });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
