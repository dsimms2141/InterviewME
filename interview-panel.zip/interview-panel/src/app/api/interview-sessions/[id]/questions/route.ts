import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { generateQuestions } from "@/lib/llm/questionGeneration";
import { toCompetencyProfile } from "@/lib/jobProfileMapper";
import type { GeneratedInterviewer } from "@/types/domain";

// Generates the five primary questions (section 12), each pre-assigned to
// the panel seat whose competency best matches it. Called once device
// check completes, so the candidate never sees questions before entering
// the room (section 11: "Do not show the candidate all questions
// beforehand in Realistic or Pressure Mode").
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({
      where: { id: params.id, userId },
      include: {
        jobProfile: true,
        panel: { include: { interviewer: true }, orderBy: { seatOrder: "asc" } },
      },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });
    if (session.panel.length !== 3) {
      return NextResponse.json({ error: "Panel must be generated before questions" }, { status: 409 });
    }

    const interviewers: GeneratedInterviewer[] = session.panel.map((m) => ({
      firstName: m.interviewer.firstName,
      lastName: m.interviewer.lastName,
      title: m.interviewer.title,
      department: m.interviewer.department,
      primaryCompetency: m.interviewer.primaryCompetency,
      interviewStyle: m.interviewer.interviewStyle,
      personality: m.interviewer.personality as GeneratedInterviewer["personality"],
      appearanceSeed: m.interviewer.appearanceSeed as GeneratedInterviewer["appearanceSeed"],
      voiceProfile: { gender: "neutral", accent: "neutral American", pace: "moderate" },
      seatOrder: m.seatOrder as 1 | 2 | 3,
    }));

    const generated = await generateQuestions({
      jobTitle: session.jobProfile.title,
      competencyProfile: toCompetencyProfile(session.jobProfile),
      interviewers,
      mode: session.mode,
    });

    const seatToInterviewerId = new Map(session.panel.map((m) => [m.seatOrder, m.interviewerId]));

    const questions = await db.$transaction(
      generated.map((q) =>
        db.question.create({
          data: {
            interviewSessionId: session.id,
            interviewerId: seatToInterviewerId.get(q.askedBySeatOrder),
            category: q.category,
            order: q.order,
            text: q.text,
            testingFor: q.testingFor,
          },
        })
      )
    );

    return NextResponse.json({ questions });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
