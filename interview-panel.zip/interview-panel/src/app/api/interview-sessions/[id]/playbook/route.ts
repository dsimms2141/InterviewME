import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

export async function GET(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({ where: { id: params.id, userId } });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    const playbook = await db.playbook.findUnique({ where: { interviewSessionId: session.id } });
    if (!playbook) return NextResponse.json({ error: "Playbook not ready yet" }, { status: 404 });

    return NextResponse.json({ playbook });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
