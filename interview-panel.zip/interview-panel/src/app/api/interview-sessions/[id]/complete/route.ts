import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { InterviewOrchestrator } from "@/lib/orchestrator/InterviewOrchestrator";
import { toCompetencyProfile } from "@/lib/jobProfileMapper";

// Called once the panel has asked its closing line (section 17). Runs the
// full coaching pipeline synchronously; the client shows a "Generating your
// feedback..." transition state while this resolves (section 18-20).
export async function POST(_req: Request, { params }: { params: { id: string } }) {
  try {
    const userId = await requireUserId();
    const session = await db.interviewSession.findFirst({
      where: { id: params.id, userId },
      include: { jobProfile: true },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    if (session.state !== "CLOSING") {
      await db.interviewSession.update({ where: { id: session.id }, data: { state: "CLOSING" } });
    }

    const orchestrator = new InterviewOrchestrator(session.id);
    await orchestrator.generateFeedback(session.jobProfile.title, toCompetencyProfile(session.jobProfile));

    return NextResponse.json({ ok: true });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
