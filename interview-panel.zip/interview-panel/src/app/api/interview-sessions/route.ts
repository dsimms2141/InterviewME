import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";

const schema = z.object({
  jobProfileId: z.string().min(1),
  mode: z.enum(["PRACTICE", "REALISTIC", "PRESSURE"]).default("REALISTIC"),
});

export async function GET() {
  try {
    const userId = await requireUserId();
    const sessions = await db.interviewSession.findMany({
      where: { userId },
      include: { jobProfile: true, evaluation: true },
      orderBy: { createdAt: "desc" },
    });
    return NextResponse.json({ interviewSessions: sessions });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}

// Creates a session in SETUP state. Panel + question generation are
// separate calls (POST .../panel, POST .../questions) so the UI can show
// per-step progress ("Analyzing job..." -> "Building your panel...") rather
// than one long blocking request.
export async function POST(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const jobProfile = await db.jobProfile.findFirst({
      where: { id: parsed.data.jobProfileId, userId },
    });
    if (!jobProfile) return NextResponse.json({ error: "Job profile not found" }, { status: 404 });

    const session = await db.interviewSession.create({
      data: {
        userId,
        jobProfileId: jobProfile.id,
        mode: parsed.data.mode,
        state: "SETUP",
      },
    });

    return NextResponse.json({ interviewSession: session }, { status: 201 });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
