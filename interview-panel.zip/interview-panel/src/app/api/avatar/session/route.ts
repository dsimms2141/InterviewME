import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { requireUserId, AuthRequiredError } from "@/lib/session";
import { withAvatarFallback } from "@/lib/avatar/providerFactory";
import { recordUsage } from "@/lib/costs/usageTracker";

const schema = z.object({ interviewerId: z.string().min(1), interviewSessionId: z.string().min(1) });

// Opens one avatar session per panelist when the candidate enters the
// interview room (state DEVICE_CHECK -> WAITING_ROOM). Sessions are created
// lazily per-panelist rather than for the whole panel up front, and
// destroyed as soon as the interview ends (section 32: "Only maintain live
// avatar sessions while an interview is actually active").
export async function POST(req: Request) {
  try {
    const userId = await requireUserId();
    const parsed = schema.safeParse(await req.json());
    if (!parsed.success) {
      return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
    }

    const session = await db.interviewSession.findFirst({
      where: { id: parsed.data.interviewSessionId, userId },
    });
    if (!session) return NextResponse.json({ error: "Interview session not found" }, { status: 404 });

    const interviewer = await db.interviewer.findUnique({ where: { id: parsed.data.interviewerId } });
    if (!interviewer) return NextResponse.json({ error: "Interviewer not found" }, { status: 404 });

    const handle = await withAvatarFallback((provider) =>
      provider.createSession({
        interviewerId: interviewer.id,
        displayName: `${interviewer.firstName} ${interviewer.lastName}`,
        appearanceSeed: interviewer.appearanceSeed as never,
        voiceProfile: { gender: "neutral", accent: "neutral American", pace: "moderate" },
      })
    );

    await recordUsage({
      interviewSessionId: session.id,
      userId,
      kind: "AVATAR_MINUTES",
      quantity: 0, // session open, not yet timed — closing call records elapsed minutes
      unit: "avatar_minutes",
      provider: handle.connectionInfo.mode === "mock" ? "mock" : process.env.AVATAR_PROVIDER || "mock",
    });

    return NextResponse.json({ session: handle });
  } catch (err) {
    if (err instanceof AuthRequiredError) return NextResponse.json({ error: err.message }, { status: 401 });
    throw err;
  }
}
