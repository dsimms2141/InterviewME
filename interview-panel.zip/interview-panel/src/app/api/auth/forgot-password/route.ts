import { NextResponse } from "next/server";
import { z } from "zod";
import { createPasswordResetToken } from "@/lib/passwordReset";
import { sendEmail, passwordResetEmail } from "@/lib/email";

const schema = z.object({ email: z.string().email() });

// When RESEND_API_KEY is configured, this sends the actual reset email via
// lib/email.ts. When it isn't (e.g. local development with no email
// provider set up), sendEmail() logs instead of sending, so this endpoint
// falls back to returning the raw token directly (`devToken`) so the reset
// flow stays testable end-to-end without an email provider.
export async function POST(req: Request) {
  const parsed = schema.safeParse(await req.json());
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.issues[0]?.message ?? "Invalid input" }, { status: 400 });
  }

  const token = await createPasswordResetToken(parsed.data.email);
  let emailSent = false;

  if (token) {
    const appUrl = process.env.NEXTAUTH_URL || "http://localhost:3000";
    const resetUrl = `${appUrl}/reset-password?token=${token}`;
    const { subject, html } = passwordResetEmail(resetUrl);
    const result = await sendEmail({ to: parsed.data.email.toLowerCase(), subject, html });
    emailSent = result.sent;
  }

  // Always return 200 regardless of whether the account exists, so this
  // endpoint can't be used to enumerate registered emails.
  return NextResponse.json({
    ok: true,
    ...(!emailSent && process.env.NODE_ENV !== "production" && token ? { devToken: token } : {}),
  });
}
