"use client";

import { useState } from "react";
import Link from "next/link";

export default function ForgotPasswordPage() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [devLink, setDevLink] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const res = await fetch("/api/auth/forgot-password", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    const data = await res.json().catch(() => ({}));
    setSubmitted(true);
    if (data.devToken) {
      setDevLink(`/reset-password?token=${data.devToken}`);
    }
  }

  return (
    <main className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-6">
      <h1 className="mb-2 text-2xl font-semibold">Reset your password</h1>
      <p className="mb-6 text-sm text-slate-400">
        Enter the email on your account and we&apos;ll send you a link to reset your password.
      </p>

      {submitted ? (
        <div className="rounded-md border border-panel-border bg-panel-surface p-4 text-sm">
          <p>If an account exists for that email, a reset link is on its way.</p>
          {devLink && (
            <p className="mt-3 text-xs text-slate-400">
              No email provider is configured in this environment — for local testing, use this link
              directly:{" "}
              <Link href={devLink} className="text-brand-300 hover:underline">
                Reset password
              </Link>
            </p>
          )}
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <label className="flex flex-col gap-1 text-sm">
            Email
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 outline-none focus:border-brand-500"
            />
          </label>
          <button
            type="submit"
            className="mt-2 rounded-md bg-brand-500 py-2 font-medium text-white transition hover:bg-brand-600"
          >
            Send reset link
          </button>
        </form>
      )}

      <p className="mt-6 text-sm text-slate-400">
        <Link href="/login" className="text-brand-300 hover:underline">
          Back to sign in
        </Link>
      </p>
    </main>
  );
}
