import { Suspense } from "react";
import { ResetPasswordForm } from "@/components/auth/ResetPasswordForm";

export default function ResetPasswordPage() {
  return (
    <Suspense fallback={<div className="mx-auto flex min-h-screen max-w-md items-center justify-center px-6 text-slate-400">Loading...</div>}>
      <ResetPasswordForm />
    </Suspense>
  );
}
