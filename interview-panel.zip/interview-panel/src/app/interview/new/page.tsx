"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

const EXAMPLE_TITLES = [
  "Operations Manager",
  "Branch Manager",
  "Project Manager",
  "Customer Service Representative",
  "Software Engineer",
  "Registered Nurse",
  "Administrative Assistant",
  "Sales Manager",
  "Director of Operations",
];

type Step = "form" | "analyzing" | "panel" | "questions" | "error";

export default function NewInterviewPage() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [mode, setMode] = useState<"PRACTICE" | "REALISTIC" | "PRESSURE">("REALISTIC");
  const [step, setStep] = useState<Step>("form");
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError(null);

    try {
      setStep("analyzing");
      const jobRes = await postJson("/api/job-profiles", {
        title,
        rawDescription: description || undefined,
        sourceType: description ? "PASTED_DESCRIPTION" : "TITLE_ONLY",
      });
      const jobProfileId = jobRes.jobProfile.id as string;

      await postJson("/api/job-profiles/analyze", { jobProfileId });

      const sessionRes = await postJson("/api/interview-sessions", { jobProfileId, mode });
      const interviewSessionId = sessionRes.interviewSession.id as string;

      setStep("panel");
      await postJson(`/api/interview-sessions/${interviewSessionId}/panel`, {});

      setStep("questions");
      await postJson(`/api/interview-sessions/${interviewSessionId}/questions`, {});

      router.push(`/interview/${interviewSessionId}/device-check`);
    } catch (err) {
      setError((err as Error).message);
      setStep("error");
    }
  }

  if (step !== "form") {
    return (
      <main className="mx-auto flex min-h-screen max-w-lg flex-col items-center justify-center px-6 text-center">
        <div className="mb-6 h-10 w-10 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
        <p className="text-lg font-medium">
          {step === "analyzing" && "Analyzing the job and building your competency profile..."}
          {step === "panel" && "Assembling your interview panel..."}
          {step === "questions" && "Writing your interview questions..."}
          {step === "error" && "Something went wrong"}
        </p>
        {step === "error" && (
          <>
            <p className="mt-2 text-sm text-red-400">{error}</p>
            <button
              onClick={() => setStep("form")}
              className="mt-4 rounded-md border border-panel-border px-4 py-2 text-sm hover:border-brand-500"
            >
              Try again
            </button>
          </>
        )}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-2xl px-6 py-12">
      <h1 className="mb-2 text-2xl font-semibold">What position are you preparing for?</h1>
      <p className="mb-8 text-slate-400">
        Give us a job title, and paste the job description if you have it — the more detail, the more
        tailored your panel and questions will be.
      </p>

      <form onSubmit={handleSubmit} className="flex flex-col gap-6">
        <label className="flex flex-col gap-2 text-sm">
          Job title
          <input
            required
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Operations Manager"
            list="example-titles"
            className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 outline-none focus:border-brand-500"
          />
          <datalist id="example-titles">
            {EXAMPLE_TITLES.map((t) => (
              <option key={t} value={t} />
            ))}
          </datalist>
        </label>

        <label className="flex flex-col gap-2 text-sm">
          Job description <span className="text-slate-500">(optional, but recommended)</span>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            rows={8}
            placeholder="Paste the job posting here..."
            className="rounded-md border border-panel-border bg-panel-surface px-3 py-2 outline-none focus:border-brand-500"
          />
        </label>

        <fieldset className="flex flex-col gap-2 text-sm">
          <legend className="mb-1">Interview difficulty</legend>
          <div className="grid gap-3 sm:grid-cols-3">
            <DifficultyCard
              value="PRACTICE"
              selected={mode === "PRACTICE"}
              title="Practice"
              description="A supportive environment to get comfortable."
              onSelect={setMode}
            />
            <DifficultyCard
              value="REALISTIC"
              selected={mode === "REALISTIC"}
              title="Realistic"
              description="Resembles an actual professional panel interview."
              onSelect={setMode}
            />
            <DifficultyCard
              value="PRESSURE"
              selected={mode === "PRESSURE"}
              title="Pressure"
              description="More challenging questions and probing follow-ups."
              onSelect={setMode}
            />
          </div>
        </fieldset>

        <button
          type="submit"
          className="mt-2 rounded-lg bg-brand-500 py-3 font-medium text-white transition hover:bg-brand-600"
        >
          Build my interview panel
        </button>
      </form>
    </main>
  );
}

function DifficultyCard({
  value,
  selected,
  title,
  description,
  onSelect,
}: {
  value: "PRACTICE" | "REALISTIC" | "PRESSURE";
  selected: boolean;
  title: string;
  description: string;
  onSelect: (v: "PRACTICE" | "REALISTIC" | "PRESSURE") => void;
}) {
  return (
    <button
      type="button"
      onClick={() => onSelect(value)}
      className={`rounded-lg border p-4 text-left transition ${
        selected ? "border-brand-500 bg-brand-500/10" : "border-panel-border bg-panel-surface hover:border-brand-500/50"
      }`}
    >
      <p className="font-medium">{title}</p>
      <p className="mt-1 text-xs text-slate-400">{description}</p>
    </button>
  );
}

async function postJson(url: string, body: unknown) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? `Request to ${url} failed`);
  return data;
}
