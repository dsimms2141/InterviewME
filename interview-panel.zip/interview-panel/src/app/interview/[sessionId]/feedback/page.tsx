import Link from "next/link";
import { getServerSession } from "next-auth";
import { redirect, notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import { DeleteRecordingButton } from "@/components/feedback/DeleteRecordingButton";

const LEVEL_COLOR: Record<string, string> = {
  STRONG: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  DEVELOPING: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  NEEDS_PRACTICE: "bg-red-500/15 text-red-400 border-red-500/30",
};

export default async function FeedbackPage({ params }: { params: { sessionId: string } }) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) redirect("/login");

  const interviewSession = await db.interviewSession.findFirst({
    where: { id: params.sessionId, userId },
    include: {
      jobProfile: true,
      evaluation: {
        include: { items: { include: { response: { include: { question: true } } } } },
      },
    },
  });
  if (!interviewSession) notFound();

  if (!interviewSession.evaluation) {
    return (
      <main className="mx-auto max-w-3xl px-6 py-16 text-center">
        <div className="mx-auto mb-6 h-10 w-10 animate-spin rounded-full border-2 border-brand-500 border-t-transparent" />
        <p className="text-lg">Your coaching feedback is still being generated...</p>
      </main>
    );
  }

  const evaluation = interviewSession.evaluation;
  const levels: [string, string][] = [
    ["Answer structure", evaluation.answerStructureLevel],
    ["Relevance", evaluation.relevanceLevel],
    ["Specificity", evaluation.specificityLevel],
    ["Problem solving", evaluation.problemSolvingLevel],
    ["Communication", evaluation.communicationLevel],
    ["STAR usage", evaluation.starUsageLevel],
    ["Conciseness", evaluation.concisenessLevel],
    ["Role knowledge", evaluation.roleKnowledgeLevel],
  ];

  return (
    <main className="mx-auto max-w-4xl px-6 py-12">
      <div className="mb-8 flex items-center justify-between">
        <div>
          <p className="text-sm text-slate-400">{interviewSession.jobProfile.title}</p>
          <h1 className="text-2xl font-semibold">Interview readiness report</h1>
        </div>
        <div className="flex gap-3">
          <Link
            href={`/interview/${interviewSession.id}/playbook`}
            className="rounded-md border border-panel-border px-4 py-2 text-sm hover:border-brand-500"
          >
            View playbook
          </Link>
          <Link
            href="/interview/new"
            className="rounded-md bg-brand-500 px-4 py-2 text-sm font-medium text-white hover:bg-brand-600"
          >
            Practice again
          </Link>
        </div>
      </div>

      <div className="mb-8 flex justify-end">
        <DeleteRecordingButton sessionId={interviewSession.id} />
      </div>

      <p className="mb-8 rounded-lg border border-panel-border bg-panel-surface p-5 text-slate-200">
        {evaluation.overallSummary}
      </p>

      <div className="mb-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
        {levels.map(([label, level]) => (
          <div key={label} className={`rounded-lg border px-4 py-3 ${LEVEL_COLOR[level]}`}>
            <p className="text-xs opacity-80">{label}</p>
            <p className="mt-1 text-sm font-medium">{level.replace("_", " ")}</p>
          </div>
        ))}
      </div>

      <section className="mb-10 grid gap-6 sm:grid-cols-2">
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Strengths</h2>
          <ul className="flex flex-col gap-2 text-sm text-slate-200">
            {(evaluation.strengths as string[]).map((s, i) => (
              <li key={i} className="rounded-md border border-panel-border bg-panel-surface p-3">
                {s}
              </li>
            ))}
          </ul>
        </div>
        <div>
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-slate-400">Growth areas</h2>
          <ul className="flex flex-col gap-2 text-sm text-slate-200">
            {(evaluation.growthAreas as string[]).map((s, i) => (
              <li key={i} className="rounded-md border border-panel-border bg-panel-surface p-3">
                {s}
              </li>
            ))}
          </ul>
        </div>
      </section>

      <h2 className="mb-4 text-lg font-semibold">Question-by-question coaching</h2>
      <div className="flex flex-col gap-5">
        {evaluation.items.map((item, i) => (
          <article key={item.id} className="rounded-xl border border-panel-border bg-panel-surface p-5">
            <p className="text-xs text-slate-500">Question {i + 1}</p>
            <p className="mb-3 font-medium">{item.response.question.text}</p>
            <p className="mb-4 text-sm text-slate-400">&quot;{item.response.transcript}&quot;</p>

            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="What worked" value={item.whatWorked} />
              <Field label="What could be stronger" value={item.whatCouldBeStronger} />
              <Field label="What this question tested" value={item.whatQuestionTested} />
              <Field label="Missing information" value={item.missingInformation} />
            </div>

            <div className="mt-4 grid gap-2 rounded-lg border border-panel-border bg-panel-bg p-4 text-sm">
              <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">STAR analysis</p>
              <p><span className="text-slate-500">Situation:</span> {item.starSituation}</p>
              <p><span className="text-slate-500">Task:</span> {item.starTask}</p>
              <p><span className="text-slate-500">Action:</span> {item.starAction}</p>
              <p><span className="text-slate-500">Result:</span> {item.starResult}</p>
            </div>

            <Field label="Better answer structure" value={item.betterAnswerStructure} className="mt-4" />
            <Field label="Coaching notes" value={item.coachingNotes} className="mt-4" />
            <Field label="Practice recommendation" value={item.practiceRecommendation} className="mt-4" />
          </article>
        ))}
      </div>
    </main>
  );
}

function Field({ label, value, className = "" }: { label: string; value: string; className?: string }) {
  return (
    <div className={className}>
      <p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{label}</p>
      <p className="mt-1 text-sm text-slate-200">{value}</p>
    </div>
  );
}
