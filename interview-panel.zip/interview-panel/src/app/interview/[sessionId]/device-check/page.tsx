import { DeviceCheck } from "@/components/device-check/DeviceCheck";

export default function DeviceCheckPage({ params }: { params: { sessionId: string } }) {
  return (
    <main className="mx-auto max-w-5xl px-6 py-12">
      <h1 className="mb-2 text-2xl font-semibold">Device check</h1>
      <p className="mb-8 text-slate-400">Let&apos;s make sure everything works before the panel joins.</p>
      <DeviceCheck sessionId={params.sessionId} />
    </main>
  );
}
