import { Suspense } from "react";
import { InterviewRoomClient } from "@/components/interview-room/InterviewRoomClient";

export default function InterviewRoomPage({ params }: { params: { sessionId: string } }) {
  return (
    <main className="mx-auto max-w-6xl px-4 py-6">
      {/* InterviewRoomClient reads the ?mode=text accessibility flag via
          useSearchParams, which Next.js requires a Suspense boundary for. */}
      <Suspense fallback={<div className="text-center text-slate-400">Loading your interview room...</div>}>
        <InterviewRoomClient sessionId={params.sessionId} />
      </Suspense>
    </main>
  );
}
