import { getServerSession } from "next-auth";
import { redirect, notFound } from "next/navigation";
import { authOptions } from "@/lib/auth";
import { db } from "@/lib/db";
import type { PlaybookContent } from "@/types/domain";
import { PrintButton } from "@/components/playbook/PrintButton";

export default async function PlaybookPage({ params }: { params: { sessionId: string } }) {
  const session = await getServerSession(authOptions);
  const userId = (session?.user as { id?: string } | undefined)?.id;
  if (!userId) redirect("/login");

  const interviewSession = await db.interviewSession.findFirst({
    where: { id: params.sessionId, userId },
    include: { playbook: true },
  });
  if (!interviewSession) notFound();

  if (!interviewSession.playbook) {
    return (
      <main className="mx-auto max-w-3xl px-6 py-16 text-center">
        <p className="text-lg">Your playbook is still being generated...</p>
      </main>
    );
  }

  const content = interviewSession.playbook.content as unknown as PlaybookContent;

  return (
    <main className="mx-auto max-w-4xl px-6 py-12 print:text-black">
      <div className="mb-8 flex items-center justify-between print:hidden">
        <h1 className="text-2xl font-semibold">Interview Playbook — {content.position}</h1>
        <PrintButton />
      </div>

      <Section title="Job competencies">
        <TagList items={content.jobCompetencies} />
      </Section>

      <Section title="Panel questions & your answers">
        <div className="flex flex-col gap-3">
          {content.panelQuestions.map((q, i) => (
            <div key={i} className="rounded-lg border border-panel-border bg-panel-surface p-4">
              <p className="font-medium">{q.question}</p>
              <p className="mt-1 text-sm text-slate-400">{q.answerSummary}</p>
            </div>
          ))}
        </div>
      </Section>

      {content.followUpQuestions.length > 0 && (
        <Section title="Follow-up questions asked">
          <div className="flex flex-col gap-3">
            {content.followUpQuestions.map((q, i) => (
              <div key={i} className="rounded-lg border border-panel-border bg-panel-surface p-4">
                <p className="font-medium">{q.question}</p>
                <p className="mt-1 text-sm text-slate-400">{q.answerSummary}</p>
              </div>
            ))}
          </div>
        </Section>
      )}

      <Section title="Feedback summary">
        <p className="text-sm text-slate-200">{content.feedback}</p>
      </Section>

      <Section title="Improved answer structures">
        <BulletList items={content.improvedAnswerStructures} />
      </Section>

      <Section title="STAR stories to reuse">
        <div className="flex flex-col gap-4">
          {content.starStories.map((s, i) => (
            <div key={i} className="rounded-lg border border-panel-border bg-panel-surface p-4">
              <p className="mb-2 font-medium">{s.title}</p>
              <p className="text-sm"><span className="text-slate-500">Situation:</span> {s.situation}</p>
              <p className="text-sm"><span className="text-slate-500">Task:</span> {s.task}</p>
              <p className="text-sm"><span className="text-slate-500">Action:</span> {s.action}</p>
              <p className="text-sm"><span className="text-slate-500">Result:</span> {s.result}</p>
            </div>
          ))}
        </div>
      </Section>

      <Section title="Areas to practice">
        <BulletList items={content.areasToPractice} />
      </Section>

      <Section title="Role-specific talking points">
        <BulletList items={content.roleTalkingPoints} />
      </Section>

      <Section title="Common questions to prepare for">
        <BulletList items={content.commonQuestionsToPrepare} />
      </Section>

      <Section title="Final preparation checklist">
        <ul className="flex flex-col gap-2 text-sm">
          {content.finalChecklist.map((item, i) => (
            <li key={i} className="flex items-start gap-2">
              <input type="checkbox" className="mt-1" />
              <span>{item}</span>
            </li>
          ))}
        </ul>
      </Section>
    </main>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="mb-8">
      <h2 className="mb-3 text-lg font-semibold">{title}</h2>
      {children}
    </section>
  );
}

function BulletList({ items }: { items: string[] }) {
  return (
    <ul className="flex flex-col gap-2 text-sm text-slate-200">
      {items.map((item, i) => (
        <li key={i} className="rounded-md border border-panel-border bg-panel-surface p-3">
          {item}
        </li>
      ))}
    </ul>
  );
}

function TagList({ items }: { items: string[] }) {
  return (
    <div className="flex flex-wrap gap-2">
      {items.map((item, i) => (
        <span key={i} className="rounded-full border border-panel-border bg-panel-surface px-3 py-1 text-xs">
          {item}
        </span>
      ))}
    </div>
  );
}
