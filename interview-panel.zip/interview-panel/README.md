# Panel Ready — AI Interview Panel Simulator

A live, animated three-person AI interview panel for job-interview practice,
built with Next.js 14, TypeScript, Prisma/Postgres, and a provider-agnostic
real-time avatar layer.

Read **[docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)** first — it covers the
stack, database schema, routes, the avatar abstraction layer and why Anam
was chosen as the default provider, third-party services and expected
costs, privacy/security, and exactly what's built vs. stubbed in this MVP
pass.

## Setup

```bash
npm install
cp .env.example .env       # fill in DATABASE_URL at minimum; see below
npm run prisma:generate
npm run prisma:migrate     # creates the schema in your Postgres database
npm run db:seed            # optional: 5 demo job profiles + demo login
npm run dev
```

### Minimum to run the full flow with real vendors

The app runs with **zero paid API keys** using its built-in fallbacks (mock
avatar provider, silent TTS, passthrough STT), so you can exercise the
whole wizard → device check → interview room → feedback → playbook flow
immediately after `npm run dev` — except the LLM calls (job analysis, panel
generation, question generation, coaching), which require:

```
ANTHROPIC_API_KEY=sk-ant-...
```

To see the real animated avatar instead of the CSS placeholder, and to hear
real interviewer voices:

```
AVATAR_PROVIDER=anam
ANAM_API_KEY=...
ELEVENLABS_API_KEY=...
```

See `.env.example` for the full list, including Deepgram (STT) and S3
(recording storage).

### A note on this session's build

This project was written in a sandboxed environment whose network policy
blocked `npm install` against the public npm registry, so it could not be
installed, type-checked, or built here. Run `npm run typecheck` as your
first step in a normal environment — see the last section of
`docs/ARCHITECTURE.md` for details.
