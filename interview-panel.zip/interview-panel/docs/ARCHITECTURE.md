# Panel Ready — AI Interview Panel Simulator: Architecture

This document follows the 12-point structure requested in the build prompt:
tech stack, database schema, routes/pages, components, APIs/services,
interview state machine, avatar abstraction layer, third-party services,
expected costs, privacy/security, project structure, and MVP status.

The repository at the root of this document (`interview-panel/`) implements
this architecture end to end: Prisma schema, avatar provider abstraction,
LLM services, the orchestrator/state machine, and the full MVP page flow
(setup wizard → device check → live interview room → coaching feedback →
playbook). See "Current build status" at the bottom for exactly what's wired
up versus stubbed.

---

## 1. Technology stack

| Layer | Choice | Why |
|---|---|---|
| Frontend + backend | **Next.js 14 (App Router), TypeScript, React 18** | One deployable for UI + API routes; server components for data-heavy pages (dashboard, feedback, playbook) avoid a separate REST layer; route handlers give us the API surface the interview room and avatar/TTS/STT calls need. |
| Styling | **Tailwind CSS** | Fast to build a premium, consistent "executive coaching + video conferencing" look (section 27) without a component library that fights the visual direction. |
| Database | **PostgreSQL** via **Prisma ORM** | Relational data (users → job profiles → sessions → questions → responses → evaluations → playbooks) with real foreign keys; Prisma gives type-safe queries and migrations. |
| Auth | **NextAuth (credentials provider today, OAuth-ready)** | Section 3's account requirements (create, sign in, sign out, reset password) map directly onto NextAuth + a `User`/`UserSettings` table; adding Google/Microsoft SSO later is a config change, not a rewrite. |
| LLM | **Anthropic Claude**, via one wrapper module (`lib/llm/client.ts`) | Job analysis, panel generation, question generation, follow-up decisions, and coaching all go through this single `completeJson()` call — swapping model/vendor touches one file. |
| Speech-to-text | **Deepgram** (server-side, source of truth) + **browser SpeechRecognition** (live captions, in-room UX) | Deepgram gives accurate, punctuated transcripts for coaching; the browser API gives zero-latency captions and "candidate finished speaking" signal with no server round-trip. |
| Text-to-speech | **ElevenLabs** | Distinct, natural voices per generated panelist; turbo model keeps latency low; output is fed to the avatar provider in audio-passthrough mode. |
| Real-time avatar | **Provider-abstracted; Anam.ai (audio-passthrough) as the default production implementation** | See section 8 below — this is the most consequential vendor decision in the app and is fully isolated behind an interface. |
| Transport (avatar video) | **WebRTC** (via whichever SDK the active avatar provider ships — LiveKit-based for Anam) | Sub-second, two-way media is required for a believable live interview; HLS/other buffered protocols are unusable here. |
| File processing | **Node `pdf-parse` / `mammoth`-style extraction (job posting uploads)** | Section 4 allows uploading a job posting/document; extracted text feeds the same `analyzeJob()` path as pasted text. |
| Storage | **S3-compatible object storage** | Recordings (when retention is enabled), exported playbook PDFs. |
| Hosting | **Vercel (app) + managed Postgres (Neon/RDS) + the above SaaS APIs** | Serverless-friendly Next.js deployment; avoids operating GPUs ourselves (see cost architecture, section 9). |

---

## 2. Database schema

Implemented in `prisma/schema.prisma`. Entities (section 30 of the brief):

- **User**, **UserSettings** — account + privacy/device preferences (camera/mic device IDs, video/audio/transcript retention toggles, captions, volume, high contrast).
- **JobProfile** — title/company/date, raw pasted/uploaded description, and the extracted **INTERVIEW COMPETENCY PROFILE** (industry, seniority, responsibilities, required/technical/behavioral skills, leadership/management expectations, communication requirements, terminology) as JSON columns.
- **Interviewer** — a generated panelist: name, title, department, primary competency, interview style, personality traits, `appearanceSeed` (demographic presentation descriptors used only for avatar rendering), and provider-side avatar/voice IDs once bound.
- **PanelMembership** — join table binding 3 `Interviewer`s to one `InterviewSession` at seats 1–3.
- **InterviewSession** — mode (PRACTICE/REALISTIC/PRESSURE), `state` (the orchestrator's state machine value), start/end time, completion status, video/audio retention flags.
- **Question** — one of the 5 primary questions (or a FOLLOW_UP), its category, order, assigned interviewer, and `testingFor` (internal-only: what competency it probes).
- **Response** — one candidate answer: transcript, optional audio URL, duration, observable signals (speaking pace, filler word count, long-pause count, STAR-structure flag), and a `parentResponseId`/`isFollowUp` link for follow-up answers.
- **Evaluation** + **EvaluationItem** — the overall readiness report (8 STRONG/DEVELOPING/NEEDS_PRACTICE dimensions, strengths, growth areas) and one coaching breakdown per response (what worked, what could be stronger, what was tested, missing info, STAR extraction, better structure, coaching notes, practice recommendation).
- **Playbook** — the generated `PlaybookContent` JSON (competencies, panel Qs/answers, follow-ups, feedback, improved structures, STAR stories, practice areas, talking points, common questions, checklist) plus an optional exported-PDF URL.
- **PracticeGoal** — progress-tracking targets ("practice STAR structure 3 more times").
- **UsageEvent** — per-provider usage records (avatar minutes, STT minutes, TTS characters, LLM tokens, storage) for the cost dashboard (section 9).

---

## 3. Routes / pages (App Router)

```
/                                   marketing / redirect to dashboard
/login, /register                   auth
/dashboard                          sections: Start New Interview, Continue
                                     Practice, Interview History, Saved Jobs,
                                     Performance Trends (stat cards)
/interview/new                      setup wizard: job title/description,
                                     difficulty → triggers analysis, panel
                                     generation, question generation
/interview/[sessionId]/device-check camera/mic permission + preview + device
                                     selection
/interview/[sessionId]/room         the live interview (panel + candidate
                                     camera + controls)
/interview/[sessionId]/feedback     per-question coaching + overall
                                     readiness report
/interview/[sessionId]/playbook     the saved, printable Interview Playbook
```

API routes (all under `src/app/api`):

```
POST   /api/auth/register
*      /api/auth/[...nextauth]                 NextAuth handler
GET,POST /api/job-profiles
POST   /api/job-profiles/analyze               → INTERVIEW COMPETENCY PROFILE
GET,POST /api/interview-sessions
GET,DELETE /api/interview-sessions/[id]
POST   /api/interview-sessions/[id]/panel      → 3-person panel
POST   /api/interview-sessions/[id]/questions  → 5 primary questions
POST   /api/interview-sessions/[id]/respond    → transcribe, analyze, decide follow-up
POST   /api/interview-sessions/[id]/complete   → run coaching + playbook generation
GET    /api/interview-sessions/[id]/evaluation
GET    /api/interview-sessions/[id]/playbook
POST   /api/avatar/session                     → open one avatar session for a panelist
POST   /api/tts                                → synthesize one line of dialogue
```

---

## 4. Components

```
components/
  interview-room/
    PanelTile.tsx          one panelist: video/placeholder + IDLE/LISTENING/
                            SPEAKING/THINKING state, name/title, speaking
                            indicator
    CandidateCamera.tsx     the candidate's own webcam feed + mic/recording badges
    Controls.tsx            mic toggle, captions toggle, "Finished answer",
                            end interview, question counter
    Captions.tsx            optional live caption bar
    InterviewRoomClient.tsx the orchestration client: loads session, drives
                            introduction → question loop → follow-ups →
                            closing → completion, wires speech recognition
                            and TTS/avatar playback
  wizard/                   job setup form, difficulty selector (folded into
                            interview/new/page.tsx for the MVP)
  device-check/
    DeviceCheck.tsx         permission request, live preview, device pickers,
                            camera/mic/network checklist
  dashboard/                stat cards, session/job lists (inlined in
                            dashboard/page.tsx)
  feedback/                 per-question coaching cards, STAR breakdown,
                            readiness level badges (inlined in feedback/page.tsx)
  playbook/
    PrintButton.tsx          window.print() trigger for the playbook page
```

---

## 5. APIs / services (`src/lib`)

```
lib/
  db.ts                     Prisma client singleton
  auth.ts                   NextAuth config (credentials provider)
  session.ts                requireUserId() helper for route handlers
  jobProfileMapper.ts        Prisma JobProfile row → CompetencyProfile domain type
  llm/
    client.ts               completeJson<T>() — the one Anthropic call site
    jobAnalysis.ts           → INTERVIEW COMPETENCY PROFILE
    panelGeneration.ts       → 3-person panel, randomized, role-appropriate
    questionGeneration.ts    → 5 primary questions, seat-assigned
    followUp.ts              → shouldFollowUp decision, capped per question
    coaching.ts               → per-answer QuestionEvaluation
    readinessReport.ts        → overall ReadinessReport (8 dimensions)
    playbook.ts                → PlaybookContent
  analysis/
    observableSignals.ts      deterministic (non-LLM) pace/filler/STAR
                               detection from a transcript — never claims to
                               infer truthfulness/personality/protected traits
  avatar/
    types.ts                  AvatarProvider interface (the abstraction seam)
    providerFactory.ts        getAvatarProvider() + withAvatarFallback()
    providers/mockProvider.ts  CSS-animated placeholder, no external calls
    providers/anamProvider.ts  Anam.ai, audio-passthrough mode (default prod)
  speech/
    tts.ts                    TtsProvider interface + ElevenLabs implementation
    stt.ts                    SttProvider interface + Deepgram implementation
  orchestrator/
    stateMachine.ts            InterviewState transition table + guard
    InterviewOrchestrator.ts   drives state transitions, follow-up decisions,
                                the full coaching pipeline
  costs/
    usageTracker.ts            recordUsage() → UsageEvent rows with cost estimates
```

---

## 6. Interview state machine

Implemented in `lib/orchestrator/stateMachine.ts` exactly as specified
(section 35):

```
SETUP → PANEL_GENERATION → DEVICE_CHECK → WAITING_ROOM → INTRODUCTION →
ASKING_QUESTION → CANDIDATE_RESPONDING → ANALYZING_RESPONSE →
  ├─ FOLLOW_UP → CANDIDATE_RESPONDING (loop, capped at 2 follow-ups/question)
  └─ NEXT_QUESTION → ASKING_QUESTION (more questions) | CLOSING (done)
CLOSING → GENERATING_FEEDBACK → COMPLETE
(any state) → ABANDONED
```

`assertTransition()` throws on any illegal jump, so a route handler can
never, say, jump straight from `SETUP` to `COMPLETE`. `InterviewOrchestrator`
is the only code that calls `db.interviewSession.update({ state })`, which
is what guarantees **only one interviewer has speaking control at a time**:
the client derives who's speaking from `state` + the active seat, never from
independent per-panelist toggles.

---

## 7. Data flow (conversational latency, section 29)

```
Candidate finishes speaking (manual button; auto-silence detection is a
  natural extension once word-level STT timestamps are wired up)
  → POST /respond
      → (if audio captured) STT transcription
      → observable-signal analysis (pace, fillers, STAR) — local, instant
      → LLM follow-up decision
  ← { followUp: string | null }
  → if follow-up: TTS the follow-up line → avatar speak() → listen again
  → else: advance to next question / closing
```

While the follow-up decision (an LLM call) is in flight, the UI holds the
active panelist in a `THINKING` state rather than a frozen screen, per
section 29 — this is wired into `PanelTile`'s `avatarState` prop; the
"processing" phase in `InterviewRoomClient` is the hook point for it.

---

## 8. Avatar abstraction layer — the critical architectural decision

### The interface

```ts
interface AvatarProvider {
  createSession(persona): Promise<AvatarSessionHandle>;
  loadAvatar(session): Promise<void>;
  speak(session, { text, audio? }): Promise<void>;
  stopSpeaking(session): Promise<void>;
  setListeningState(session): Promise<void>;
  setIdleState(session): Promise<void>;
  destroySession(session): Promise<void>;
}
```

Every call site in the app (the interview room, the avatar/session and tts
API routes) talks to this interface only — never to a vendor SDK directly.
`getAvatarProvider()` reads `AVATAR_PROVIDER` and returns the matching
implementation; `withAvatarFallback()` wraps any call so a **recoverable**
provider failure (network error, 5xx, rate limit) degrades to the mock
(non-animated-but-functional) provider for that one call, rather than
crashing the interview, per section 8's "graceful fallback" requirement.

### Pipeline

```
TEXT (LLM question/follow-up) → TTS (ElevenLabs) → avatar.speak({ audio })
  → WebRTC stream → <video> track in PanelTile
```

Using **audio-passthrough / bring-your-own-TTS** mode (rather than an
avatar vendor's own built-in LLM+TTS bundle) means:
- One TTS vendor and voice roster across every panelist, regardless of
  which avatar vendor renders them.
- The LLM, TTS, and avatar vendors can each be swapped independently.
- It matches how `AvatarProvider.speak()` is already typed (`audio` is
  required for the Anam implementation; a provider with native TTS could
  accept `text`-only and still satisfy the same interface).

### Why Anam (production default) over the alternatives

Researched as of September 2026 (see inline comments in
`anamProvider.ts` for the "confirm against current docs before going live"
caveat — this is a fast-moving vendor category):

| Provider | Model | Pricing shape | Notes |
|---|---|---|---|
| **Anam.ai** (chosen) | Self-serve tiers, ~$0.11–0.16/min blended, down to ~$0.11/min at the Professional tier | Per-second billing, explicit overage rates, clean audio-passthrough/BYO-TTS docs (`docs.anam.ai/examples/custom-tts`), WebRTC transport | Clearest self-serve pricing page in the category as of this writing; EU-headquartered (relevant if data residency ever matters); "180ms" latency claims are for their own turnkey STT+LLM+TTS path, not audio-passthrough — passthrough adds the app's own STT/LLM/TTS latency on top. |
| HeyGen **LiveAvatar** | Full mode (bundled LLM+TTS) ~$0.20–0.24/min; Lite (BYO) roughly half that, falling toward ~$0.01/min at high volume on published rate-card claims | Separate product/pricing from HeyGen's video-generation API — easy to accidentally price against the wrong page | Strong option if committing to HeyGen's own LLM/TTS bundle; less natural fit for our BYO-TTS, multi-vendor-swap design goal. |
| Simli | ~$0.009/min for rendering only | Cheapest *rendering-only* line item, but STT/LLM/TTS/transport are all separate — total cost is not directly comparable to a bundled quote | Good fallback/second-vendor candidate given the low base rendering cost once the rest of the pipeline is proven. |
| Tavus | Sub-500ms latency claims, per-minute bundled pricing | Full stack (perception + rendering + dialogue) — more opinionated, less BYO-friendly | Strong quality bar; evaluate if Anam's benchmark claims don't hold up in our own testing. |

**Given the requirement to keep the vendor swappable, the specific choice
matters less than the seam.** `AvatarProvider` is designed so adding, say,
`SimliAvatarProvider` or `HeyGenLiveAvatarProvider` is: write one new class
implementing the 7 methods, add one `case` to `providerFactory.ts`, set
`AVATAR_PROVIDER=simli`. Nothing in the orchestrator, API routes, or UI
changes.

### Client-side rendering

`PanelTile.tsx` currently renders the **mock provider's** CSS-animated
placeholder (idle sway, blink loop, a mouth-pulse keyed off speaking state)
so the full interview flow is demoable with zero avatar vendor cost. The
production swap is: replace the placeholder `<div>` with the avatar
provider's video element (e.g. a LiveKit `<VideoTrack>` for Anam), driven by
the same `avatarState` prop — the state machine, not the rendering, is what
this component is built around.

---

## 9. Third-party services required + expected costs

| Service | Used for | Env var(s) | Rough cost driver |
|---|---|---|---|
| Anthropic Claude | job analysis, panel/question generation, follow-up decisions, coaching, readiness report, playbook | `ANTHROPIC_API_KEY` | ~6–10 LLM calls/interview; token cost dominated by coaching (long context) — budget ~$0.05–0.15/interview at current Sonnet-class pricing. |
| Anam.ai (or swapped avatar vendor) | real-time animated panelist video | `ANAM_API_KEY` | **Largest single cost.** 3 concurrent avatar sessions × interview length. A 15-minute REALISTIC-mode interview ≈ 45 avatar-minutes ≈ **$5–7** at blended self-serve rates — this is why section 32's "only run sessions while active, terminate immediately" matters. |
| ElevenLabs | interviewer TTS | `ELEVENLABS_API_KEY` | Billed per character; a full interview's dialogue is a few thousand characters — a few cents. |
| Deepgram | candidate answer transcription | `DEEPGRAM_API_KEY` | ~$0.006/min; a 15-minute interview's worth of candidate speech ≈ a few cents. |
| S3-compatible storage | optional recordings, exported playbook PDFs | `S3_BUCKET`, `AWS_*` | Negligible unless video retention is broadly opted into. |
| Postgres hosting | all relational data | `DATABASE_URL` | Standard managed-Postgres pricing. |

`lib/costs/usageTracker.ts` records every one of these as a `UsageEvent` row
with an estimated USD cost, so the eventual analytics dashboard (section 22)
can show real per-interview cost, not just aggregate provider invoices.

**Practical implication:** at ~$5–7/interview dominated by avatar minutes,
this is the number to renegotiate first at scale (a vendor contract,
Simli's cheaper rendering-only line item, or self-hosting per section 8's
"$0.06–0.12/min custom path" once volume justifies the GPU/on-call cost)
before optimizing anything else.

---

## 10. Privacy & security considerations

- **Camera/microphone**: never activated without the explicit
  `getUserMedia()` prompt in `DeviceCheck.tsx`; no background activation
  anywhere in the codebase.
- **Recording disclosure**: the device-check screen states plainly that
  recording/transcription begins only once the candidate enters the room.
  `UserSettings.saveVideoRecordings` defaults to `false` ("DO NOT SAVE
  VIDEO" is the default posture); audio defaults to retained (needed for
  STT-based coaching) but is independently toggleable.
- **No raw video required for coaching**: the coaching pipeline runs
  entirely off the transcript + duration; video is used for immersion and
  optional presentation feedback only, never for scoring.
- **No inferred protected characteristics**: `observableSignals.ts` and
  every coaching/readiness LLM prompt explicitly forbid claims about
  truthfulness, intelligence, personality, race/ethnicity, religion, sexual
  orientation, disability, medical condition, political beliefs, or
  employment suitability from appearance — this is enforced in the prompt
  text itself (sections 2, 16), not left to model discretion alone.
- **No hire/no-hire claims**: the readiness-report prompt explicitly bans
  "you would/would not be hired" language in favor of coaching-oriented
  phrasing.
- **Panel diversity without competence-linkage**: `panelGeneration.ts`'s
  prompt explicitly instructs that appearance fields are for rendering only
  and must never correlate with competence, seniority, or scoring.
- **Secrets**: every provider key (`ANTHROPIC_API_KEY`, `ANAM_API_KEY`,
  `ELEVENLABS_API_KEY`, `DEEPGRAM_API_KEY`, AWS credentials) is read
  server-side only (route handlers, `lib/*`) — nothing is passed to the
  client. The client only ever talks to this app's own `/api/*` routes.
- **Auth**: passwords hashed with bcrypt (cost 12); NextAuth JWT sessions;
  every data-bearing route calls `requireUserId()` and scopes every Prisma
  query by `userId` (or by session ownership for session-scoped resources).
- **Deletion**: `DELETE /api/interview-sessions/[id]` cascades through
  Prisma relations (panel memberships, questions, responses, evaluation,
  playbook) — implementing the "delete interviews / delete recordings"
  requirement (section 3) as a single relational delete rather than a
  manual multi-table cleanup that could leak orphaned rows.
- **Rate limiting / input validation**: every route handler validates its
  body with `zod` before touching the database or calling an LLM; rate
  limiting (e.g. per-user request caps on `/respond` and `/tts`) is called
  out here as a pre-launch hardening step, not yet wired into the MVP code.

---

## 11. Project structure

```
interview-panel/
  prisma/
    schema.prisma
    seed.ts                 5 demo job profiles + a demo account
  src/
    app/                    pages + API routes (see section 3)
    components/             see section 4
    lib/                    see section 5
    types/
      domain.ts             LLM-facing domain types (CompetencyProfile,
                             GeneratedPanel, QuestionEvaluation, ...)
      next-auth.d.ts         session/JWT type augmentation
  docs/
    ARCHITECTURE.md          this document
  .env.example
```

---

## 12. Current build status (MVP vs. future)

**Built in this pass** (matches section 33's MVP list):

- Auth (register/sign in/sign out), dashboard, job setup wizard with
  title/pasted-description input and difficulty selection.
- Job analysis → competency profile extraction (LLM).
- Randomized, role-appropriate 3-person panel generation (LLM), persisted.
- Device check (camera/mic permission, preview, device selection, network
  status).
- Live interview room: animated panel tiles (mock provider by default, real
  provider swap-in point documented above), candidate camera, 5 primary
  questions with LLM-decided, capped follow-ups, live captions via browser
  speech recognition, manual "Finished answer" control.
- Server-side transcription hook (Deepgram, or passthrough of the browser
  transcript when no STT key is configured).
- Full state-machine-driven orchestration (only one panelist speaks at a
  time; illegal transitions rejected).
- Per-question coaching, overall readiness report, and a saved, printable
  Interview Playbook (all LLM-generated from the actual transcript, with
  fabrication explicitly disallowed in every coaching prompt).
- "Practice again" from feedback → back into the wizard (the retry system's
  simplest form; targeted retry using weak areas is a direct extension of
  `PracticeGoal` + passing prior `growthAreas` into `questionGeneration.ts`
  as a steering hint).
- Cost/usage tracking (`UsageEvent`) wired into TTS, STT, and avatar-session
  calls.

**Built in a second pass** (in response to "let's start building it"):

- **Password reset flow**: `PasswordResetToken` model (hashed, single-use,
  30-minute-TTL tokens), `POST /api/auth/forgot-password` +
  `POST /api/auth/reset-password`, and `/forgot-password` / `/reset-password`
  pages. No email provider is wired up yet — in non-production, the forgot-
  password endpoint returns the raw token directly (`devToken`) so the flow
  is testable end-to-end; swap that for an actual email send (and drop
  `devToken` from the response) before going to production.
- **Video/audio upload to S3**: `lib/storage.ts` (lazy-loaded
  `@aws-sdk/client-s3`) now backs `Response.audioUrl`. `respond/route.ts`
  uploads audio only when `UserSettings.saveAudioRecordings` is true
  (default), and `DELETE /api/interview-sessions/[id]/recording` (section
  3's "delete recordings," separate from deleting the whole interview) now
  actually deletes the S3 object, not just the stored URL.
- **Settings page** (`/dashboard/settings`): camera/mic device preference,
  audio volume, and the privacy toggles from `UserSettings` (video/audio/
  transcript retention, captions-by-default, high contrast), backed by
  `GET`/`PATCH /api/settings`.
- **Saved Jobs page** (`/dashboard/jobs`): lists every `JobProfile`, "Practice
  again" per difficulty (skips straight to panel + question generation
  since the competency profile is already extracted), and delete.
- **Performance Trends** on the dashboard: `lib/analysis/performanceTrends.ts`
  turns `Response` rows into average-answer-length, filler-word-trend, and
  STAR-structure-trend indicators (first-half vs. second-half comparison) —
  descriptive only, never converted into a score, per section 22.
- **Delete interview / delete recording** actions wired into the dashboard
  and feedback page UI (the API routes existed already; they weren't
  reachable from a button before).

**Built in a third pass:**

- **Auto-silence detection**: `InterviewRoomClient.tsx` now auto-submits an
  answer after `AUTO_SILENCE_MS` (4.5s) of no new recognized speech,
  gated behind a minimum listening duration so a slow mic/recognition
  startup can't trigger an instant submit. This is purely additive — the
  manual "Finished answer" button is unchanged and remains the primary
  control, per section 14's "do not interrupt on a brief pause."
  Word-level STT timestamps (a streaming, not REST, Deepgram connection)
  would allow a tighter, speech-aware version of this later.
- **Accessibility text-response path**: a "Type my answer instead" toggle
  in the interview room swaps the microphone/live-transcript flow for a
  plain textarea, with no camera or microphone required for that answer.
- **Camera-optional accessibility path**: device check now offers "Continue
  without a camera (audio only)" and "Skip camera and microphone — I'll
  type my answers," in addition to the full camera+mic flow; the interview
  room reads the choice (a `?mode=text` flag for the fully-typed path) and
  never calls `getUserMedia` at all in that case.
- **Transactional email**: `lib/email.ts` wraps Resend's REST API (no SDK
  dependency) and is wired into `forgot-password/route.ts`. Unset
  `RESEND_API_KEY` and it degrades to logging the email and returning the
  raw reset token in the response, so the flow still works end-to-end in
  local development.

**Still stubbed / next steps:**

- **Avatar provider**: ships with the mock (CSS-animated) provider active
  by default and a fully-typed `AnamAvatarProvider` ready to activate by
  setting `AVATAR_PROVIDER=anam` + `ANAM_API_KEY` — the REST payload shapes
  in `anamProvider.ts` should be checked against Anam's current API
  reference before a production cutover (this category's APIs move fast).
- **Organization/B2B version** (section 34): intentionally not started —
  the brief explicitly scopes this to "architect so it *can* exist later,"
  and nothing in the current schema or auth model blocks adding an
  `Organization`/`Program`/`QuestionBank` layer on top.
- **Device selection for the audio-only accessibility path**: the full
  camera+mic flow lets the candidate pick a specific microphone; the
  audio-only fallback currently uses the system default mic rather than
  also offering a picker — a small follow-up, not a missing capability.

### A note on this session's build environment

This project was scaffolded and written in a sandboxed cloud workspace whose
outbound network policy blocks `registry.npmjs.org` (confirmed via a direct
`403 host_not_allowed` from the registry itself, not a transient error), so
`npm install`, `prisma generate`, and a build/typecheck pass could not be
run here. Every file was written and manually cross-checked for import
correctness, Prisma schema/type alignment, and React hook dependency
correctness, but **run `npm install && npm run prisma:generate && npm run
typecheck` as the first step in an environment with normal npm registry
access** before treating this as verified-green. That's also the point to
run `npm run db:seed` against a real Postgres instance to get the 5 demo
job profiles and a demo login (`demo@panelready.app` / `demo-password-123`).
