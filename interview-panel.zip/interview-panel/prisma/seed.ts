// Demo data (section 39): five job profiles with pre-filled competency
// profiles, so the dashboard has something to show without requiring an
// LLM call on first run. Panels and questions are still generated live via
// the LLM the first time a candidate starts an interview against one of
// these — only the competency extraction step is pre-seeded here.
import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const db = new PrismaClient();

const DEMO_POSITIONS = [
  {
    title: "Operations Manager",
    industry: "Retail Operations",
    seniority: "First-line manager",
    responsibilities: ["Daily operations oversight", "Staff scheduling", "Budget management", "Vendor coordination"],
    requiredSkills: ["Process optimization", "Team leadership", "P&L management"],
    leadershipExpectations: ["Coaching frontline supervisors", "Setting performance goals"],
    technicalCompetencies: ["Inventory systems", "Scheduling software"],
    behavioralCompetencies: ["Decisiveness", "Adaptability"],
    customerResponsibilities: ["Escalation resolution"],
    problemSolvingExpectations: ["Root-cause analysis of operational issues"],
    communicationRequirements: ["Cross-department coordination"],
    managementExpectations: ["Direct reports: 3-8 supervisors"],
    relevantTerminology: ["SLA", "shrinkage", "labor variance"],
  },
  {
    title: "Project Manager",
    industry: "Professional Services",
    seniority: "Mid-level individual contributor",
    responsibilities: ["Project planning", "Stakeholder communication", "Risk management", "Timeline ownership"],
    requiredSkills: ["Agile/Scrum", "Budgeting", "Stakeholder management"],
    leadershipExpectations: [],
    technicalCompetencies: ["Jira", "Gantt charts"],
    behavioralCompetencies: ["Organization", "Conflict resolution"],
    customerResponsibilities: ["Client status reporting"],
    problemSolvingExpectations: ["Scope creep mitigation"],
    communicationRequirements: ["Executive status updates"],
    managementExpectations: [],
    relevantTerminology: ["sprint", "critical path", "RAID log"],
  },
  {
    title: "Customer Service Supervisor",
    industry: "Contact Center",
    seniority: "First-line manager",
    responsibilities: ["Queue management", "Agent coaching", "Escalation handling", "QA reviews"],
    requiredSkills: ["De-escalation", "Coaching", "CRM tools"],
    leadershipExpectations: ["Team of 8-15 agents"],
    technicalCompetencies: ["CRM systems", "Workforce management tools"],
    behavioralCompetencies: ["Patience", "Empathy under pressure"],
    customerResponsibilities: ["Tier-2 escalations"],
    problemSolvingExpectations: ["Handling repeat-contact drivers"],
    communicationRequirements: ["Agent feedback delivery"],
    managementExpectations: ["Shift scheduling"],
    relevantTerminology: ["AHT", "CSAT", "first-contact resolution"],
  },
  {
    title: "Software Engineer",
    industry: "Technology",
    seniority: "Mid-level individual contributor",
    responsibilities: ["Feature development", "Code review", "On-call rotation", "Technical design docs"],
    requiredSkills: ["System design", "Testing", "Debugging"],
    leadershipExpectations: [],
    technicalCompetencies: ["TypeScript/React or similar stack", "CI/CD", "Databases"],
    behavioralCompetencies: ["Collaboration", "Handling ambiguity"],
    customerResponsibilities: [],
    problemSolvingExpectations: ["Production incident triage"],
    communicationRequirements: ["Technical design reviews"],
    managementExpectations: [],
    relevantTerminology: ["PR", "on-call", "tech debt"],
  },
  {
    title: "Registered Nurse",
    industry: "Healthcare",
    seniority: "Individual contributor",
    responsibilities: ["Patient assessment", "Medication administration", "Care coordination", "Documentation"],
    requiredSkills: ["Clinical judgment", "EHR systems", "Patient education"],
    leadershipExpectations: [],
    technicalCompetencies: ["EHR/EMR systems", "Vital sign monitoring"],
    behavioralCompetencies: ["Composure under pressure", "Compassion"],
    customerResponsibilities: ["Patient and family communication"],
    problemSolvingExpectations: ["Rapid clinical decision-making"],
    communicationRequirements: ["Interdisciplinary handoffs"],
    managementExpectations: [],
    relevantTerminology: ["charting", "triage", "care plan"],
  },
];

async function main() {
  const email = "demo@panelready.app";
  const hashedPassword = await bcrypt.hash("demo-password-123", 12);

  const user = await db.user.upsert({
    where: { email },
    update: {},
    create: {
      email,
      hashedPassword,
      name: "Demo Candidate",
      settings: { create: {} },
    },
  });

  for (const position of DEMO_POSITIONS) {
    const exists = await db.jobProfile.findFirst({ where: { userId: user.id, title: position.title } });
    if (exists) continue;

    await db.jobProfile.create({
      data: {
        userId: user.id,
        title: position.title,
        sourceType: "TITLE_ONLY",
        industry: position.industry,
        seniority: position.seniority,
        responsibilities: position.responsibilities,
        requiredSkills: position.requiredSkills,
        leadershipExpectations: position.leadershipExpectations,
        technicalCompetencies: position.technicalCompetencies,
        behavioralCompetencies: position.behavioralCompetencies,
        customerResponsibilities: position.customerResponsibilities,
        problemSolvingExpectations: position.problemSolvingExpectations,
        communicationRequirements: position.communicationRequirements,
        managementExpectations: position.managementExpectations,
        relevantTerminology: position.relevantTerminology,
      },
    });
  }

  console.log(`Seeded demo account: ${email} / demo-password-123`);
}

main()
  .catch((err) => {
    console.error(err);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
